"""
data_preprocessing.py — Data Loading & Preprocessing
======================================================
Unified RL-MTL-LLM EV Charging Framework.

Contains:
  - Config: central dataclass with all hyperparameters / paths
  - set_seed / get_logger: reproducibility & logging helpers
  - UrbanEVLoader, MultiFacetedLoader, SaudiEVCSLoader: per-dataset
    loading + feature engineering (imputation, per-zone normalisation,
    cyclical temporal encoding, KNN spatial graph construction)
  - MTLWindowDataset: sliding-window PyTorch Dataset used by the MTL
    forecaster in model.py
"""
import os
import sys
import random
import warnings
import logging
from typing import Dict, List, Tuple
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

import torch
from torch.utils.data import Dataset

warnings.filterwarnings("ignore")

# ══════════════════════════════════════════════════════════════════════════════
# Dataset paths — EDIT THESE to match your local / Kaggle dataset mount point
# ══════════════════════════════════════════════════════════════════════════════
URBANEV_PATH    = ""
MF_PATH         = ""
SAUDI_PATH      = ""
SAVE_DIR = ""
BASE_PATH = URBANEV_PATH
os.makedirs(SAVE_DIR, exist_ok=True)

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 1: CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Config:
    """
    Centralised configuration for the entire pipeline.
    All hyperparameters are documented with their rationale.
    """
    # ── Data Paths ────────────────────────────────────────────────────────────
    base_path: str = BASE_PATH
    save_dir:  str = SAVE_DIR

    # ── Temporal ─────────────────────────────────────────────────────────────
    # 12-hour window: captures full half-day cycle, validated in MTL literature
    window_size: int = 12
    # Horizons: 1h (short), 3h (medium), 6h and 9h (long) — matches Paper 5
    forecast_horizons: List[int] = field(default_factory=lambda: [1, 3, 6, 9])

    # ── Data Splits (chronological, no leakage) ───────────────────────────────
    train_ratio: float = 0.70   # ~3041 hours
    val_ratio:   float = 0.10   # ~434  hours
    # test = 0.20               # ~869  hours

    # ── MTL Model ─────────────────────────────────────────────────────────────
    # hidden_dim=64: balanced capacity for T4 (15 GB) — use 128 on A100/V100
    hidden_dim:      int   = 64
    num_layers:      int   = 2
    dropout:         float = 0.2
    backbone:        str   = "LSTM"    # "LSTM" or "TCN"
    embedding_dim:   int   = 16        # station embedding: sqrt(n_zones) ≈ 16
    tcn_channels:    List[int] = field(default_factory=lambda: [64, 128, 128, 64])
    tcn_kernel_size: int   = 2
    # Dilations mirror Paper 5: {2^0, 2^1, 2^2, 2^3}
    tcn_dilations:   List[int] = field(default_factory=lambda: [1, 2, 4, 8])
    # zone_chunk: how many zones to process at once in forward().
    # Lower = less VRAM. 32 uses ~800 MB peak on T4 with batch_size=64.
    zone_chunk:      int   = 32

    # ── MTL Training ──────────────────────────────────────────────────────────
    batch_size:                int   = 256
    max_epochs:                int   = 100
    learning_rate:             float = 1e-3
    lr_decay_rate:             float = 0.9
    lr_decay_steps:            int   = 10_000
    early_stopping_patience:   int   = 10
    grad_clip_norm:            float = 1.0
    weight_init_alpha:         float = 0.5   # initial MTL loss weight per task

    # ── RL Environment ────────────────────────────────────────────────────────
    # K=8 neighbours: typical urban zone connectivity
    n_neighbors:      int   = 8
    n_zone_features:  int   = 7       # per-zone feature vector length
    n_temporal_feats: int   = 6       # sin/cos × {hour, dow, month}
    max_episode_steps: int  = 48      # 48-hour recommendation horizon
    # Reward weights: occupancy (O4) > distance (O1) > cost (O6) > charger (O3)
    reward_w_occupancy: float = 0.40
    reward_w_distance:  float = 0.25
    reward_w_cost:      float = 0.20
    reward_w_charger:   float = 0.15

    # ── RL Training ───────────────────────────────────────────────────────────
    rl_total_steps:    int  = 300_000
    rl_eval_freq:      int  = 10_000
    rl_n_eval_eps:     int  = 20
    ppo_n_steps:       int  = 2048
    ppo_batch_size:    int  = 64
    ppo_n_epochs:      int  = 10
    ppo_gamma:         float = 0.99
    ppo_gae_lambda:    float = 0.95
    ppo_clip_range:    float = 0.2
    ppo_learning_rate: float = 3e-4
    ppo_ent_coef:      float = 0.01

    # ── LLM ───────────────────────────────────────────────────────────────────
    llm_model_name:    str = "gpt2"
    llm_max_new_tokens: int = 80
    llm_temperature:   float = 0.7
    llm_top_p:         float = 0.9

    # ── Reproducibility ───────────────────────────────────────────────────────
    seed: int = 42
    device: str = field(
        default_factory=lambda: "cuda" if torch.cuda.is_available() else "cpu"
    )

    # ── Visualisation ─────────────────────────────────────────────────────────
    fig_dpi:    int   = 300
    fig_format: str   = "png"
    palette:    List[str] = field(default_factory=lambda: [
        "#028090", "#E63946", "#F4A261", "#457B9D", "#2A9D8F",
        "#E9C46A", "#264653", "#F0EFEB",
    ])


# ── Global Helpers ─────────────────────────────────────────────────────────────

def set_seed(seed: int) -> None:
    """Fix all random seeds for full reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    os.environ["PYTHONHASHSEED"] = str(seed)


def get_logger(name: str, level: str = "INFO") -> logging.Logger:
    """Consistent logger across all modules."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        fmt = logging.Formatter(
            "[%(asctime)s | %(name)s | %(levelname)s] %(message)s",
            datefmt="%H:%M:%S",
        )
        handler.setFormatter(fmt)
        logger.addHandler(handler)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    return logger


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 2: DATA LOADING & PREPROCESSING (all 3 datasets)
# ══════════════════════════════════════════════════════════════════════════════

class UrbanEVLoader:
    """
    Loads and preprocesses all UrbanEV dataset files.

    Preprocessing strategy (follows UrbanEV paper recommendations):
      1. Load hourly CSVs — occupancy, volume, price, duration
      2. Load static files — adjacency, distance, zone info
      3. Impute missing values — forward fill then backward fill per zone
      4. Normalise per zone with StandardScaler (fit on train only)
      5. Encode temporal features cyclically (sin/cos)
      6. Build spatial graph with K nearest neighbours per zone
      7. Derive static features: fast_ratio, normalised pile count

    Data leakage prevention:
      - All scalers fitted exclusively on training split
      - Test/val data transformed (not fitted) with train scalers
    """

    def __init__(self, cfg: Config):
        self.cfg    = cfg
        self.logger = get_logger("DataLoader")
        self.hour_dir = os.path.join(cfg.base_path, "charge_1hour")

        # Filled by load()
        self.occ:        pd.DataFrame = None
        self.vol:        pd.DataFrame = None
        self.dur:        pd.DataFrame = None
        self.e_price:    pd.DataFrame = None
        self.s_price:    pd.DataFrame = None
        self.adj:        np.ndarray   = None
        self.dist:       np.ndarray   = None
        self.zone_info:  pd.DataFrame = None
        self.zones:      List[str]    = None
        self.n_zones:    int          = 0
        self.timestamps: pd.DatetimeIndex = None

        # Filled by build_features()
        self.features:    np.ndarray  = None  # (T, Z, F)
        self.targets_occ: np.ndarray  = None  # (T, Z)
        self.targets_vol: np.ndarray  = None  # (T, Z)
        self.scalers_occ: List[StandardScaler] = []
        self.scalers_vol: List[StandardScaler] = []
        self.fast_ratio:  np.ndarray  = None  # (Z,)
        self.neighbors:   List[List[int]] = [] # (Z, K)

        # Split indices
        self.train_end: int = 0
        self.val_end:   int = 0

    # ── File I/O ───────────────────────────────────────────────────────────

    def _read_hourly(self, fname: str) -> pd.DataFrame:
        path = os.path.join(self.hour_dir, fname)
        df = pd.read_csv(path, index_col=0)
        df.index = pd.to_datetime(df.index)
        df.columns = df.columns.astype(str)
        return df

    def _align_zones(self, dfs: List[pd.DataFrame]) -> List[pd.DataFrame]:
        """
        Retain only zones present in ALL DataFrames.
        Sorts numerically (int key) since zone IDs like '102' and '1000'
        sort incorrectly under lexicographic ordering ('1000' < '102').
        """
        common = set(dfs[0].columns.astype(str))
        for df in dfs[1:]:
            common &= set(df.columns.astype(str))
        try:
            common = sorted(common, key=lambda x: int(x))
        except ValueError:
            common = sorted(common)
        aligned = []
        for df in dfs:
            df.columns = df.columns.astype(str)
            aligned.append(df[common])
        return aligned, common

    def load(self) -> "UrbanEVLoader":
        """
        Load all UrbanEV CSV files with correct handling for each file's format.

        Key format facts discovered from diagnostic inspection:
          - occupancy/volume/etc: datetime index, zone IDs as string columns
          - adj.csv / distance.csv: NO proper row index — first column is zone data
            (zone 102), NOT a zone-ID index. Must read without index_col=0 and
            assign columns as row index to produce a proper square matrix.
          - zone-information.csv: TAZID (1066, 1068...) is a different numbering
            system from sequential zone IDs (102, 104...) — no direct join.
          - occupancy values are raw pile-usage counts (e.g. 17.0), not 0-1 ratios.
        """
        self.logger.info("Loading UrbanEV dataset …")

        # ── Time-series files ─────────────────────────────────────────────────
        occ = self._read_hourly("occupancy.csv")
        vol = self._read_hourly("volume.csv")
        dur = self._read_hourly("duration.csv")
        ep  = self._read_hourly("e_price.csv")
        sp  = self._read_hourly("s_price.csv")

        # Align: keep only zones present in all five time-series files
        [occ, vol, dur, ep, sp], zones = self._align_zones([occ, vol, dur, ep, sp])

        # ── Adjacency & Distance ──────────────────────────────────────────────
        # CRITICAL: Do NOT use index_col=0 for these files.
        # Structure of adj.csv (and distance.csv):
        #   - Row 0 (header): zone IDs → ['102', '104', '105', ...]  (275 cols)
        #   - Rows 1-275: values for each zone pair
        # When read with index_col=0, the first data column (zone 102) is silently
        # treated as the row index, leaving only 274 columns and giving incorrect
        # index values (adjacency 0/1 or distance values instead of zone IDs).
        adj_path  = os.path.join(self.cfg.base_path, "adj.csv")
        dist_path = os.path.join(self.cfg.base_path, "distance.csv")

        adj_df  = pd.read_csv(adj_path,  index_col=None)  # → (275, 275)
        dist_df = pd.read_csv(dist_path, index_col=None)  # → (275, 275)

        # Ensure column names are strings so they match time-series zone IDs
        adj_df.columns  = adj_df.columns.astype(str)
        dist_df.columns = dist_df.columns.astype(str)

        # These are square symmetric matrices: rows represent the same zones
        # as columns. Assign columns as row index for .loc[zone, zone] access.
        adj_df.index  = adj_df.columns.tolist()
        dist_df.index = dist_df.columns.tolist()

        self.logger.info(
            f"adj shape after fix: {adj_df.shape}, "
            f"col sample: {adj_df.columns[:5].tolist()}"
        )

        # Intersect: zones present in both time-series AND spatial files
        spatial_zones = set(adj_df.columns) & set(dist_df.columns)
        zones = sorted(
            set(zones) & spatial_zones,
            key=lambda x: int(x)
        )
        if not zones:
            raise ValueError(
                f"No common zones found after intersection. "
                f"Time-series sample: {list(occ.columns[:5])} | "
                f"adj.csv columns sample: {list(adj_df.columns[:5])}"
            )

        self.logger.info(f"Common zones across all files: {len(zones)}")

        # Filter all DataFrames to the final common zone set
        self.occ     = occ[zones]
        self.vol     = vol[zones]
        self.dur     = dur[zones]
        self.e_price = ep[zones]
        self.s_price = sp[zones]

        adj_arr  = adj_df.loc[zones, zones].values.astype(np.float32)
        dist_arr = dist_df.loc[zones, zones].values.astype(np.float32)

        # Zero out diagonal (no self-loops)
        np.fill_diagonal(adj_arr,  0)
        np.fill_diagonal(dist_arr, 0.0)

        self.adj  = adj_arr
        self.dist = dist_arr

        # ── Static info files ─────────────────────────────────────────────────
        # zone-information.csv: indexed by TAZID (1066, 1068...) which is the
        # original Shenzhen survey zone ID — NOT the same as sequential zone IDs
        # (102, 104...) used in time-series files. No direct join is possible.
        # We load for global statistics only (total pile counts, area averages).
        zi_path       = os.path.join(self.cfg.base_path, "zone-information.csv")
        si_path       = os.path.join(self.cfg.base_path, "station_information.csv")
        self.zone_info = pd.read_csv(zi_path)
        self.sta_info  = pd.read_csv(si_path)

        # Store key attributes
        self.zones      = zones
        self.n_zones    = len(zones)
        self.timestamps = self.occ.index

        self.logger.info(
            f"Loaded: {len(self.timestamps)} timestamps × {self.n_zones} zones"
        )
        return self
    # ── Feature Engineering ───────────────────────────────────────────────

    def _impute(self, df: pd.DataFrame) -> pd.DataFrame:
        """Forward fill then backward fill per zone; fill remaining with 0."""
        return df.ffill().bfill().fillna(0.0)

    def _cyclical(self, values: np.ndarray, period: float) -> Tuple[np.ndarray, np.ndarray]:
        """Encode periodic variable as sin/cos pair to preserve continuity."""
        angle = 2 * np.pi * values / period
        return np.sin(angle), np.cos(angle)

    def _build_temporal(self) -> np.ndarray:
        """
        Build temporal feature matrix (T × 6).
        Features: sin_hour, cos_hour, sin_dow, cos_dow, sin_month, cos_month
        Rationale: Cyclical encoding avoids artificial discontinuity at
                   period boundaries (23:00→00:00, Sun→Mon, Dec→Jan).
        """
        hours  = self.timestamps.hour.values.astype(float)
        dows   = self.timestamps.dayofweek.values.astype(float)
        months = (self.timestamps.month.values - 1).astype(float)

        sh, ch = self._cyclical(hours,  24.0)
        sd, cd = self._cyclical(dows,    7.0)
        sm, cm = self._cyclical(months, 12.0)

        return np.stack([sh, ch, sd, cd, sm, cm], axis=1).astype(np.float32)  # (T, 6)

    def _build_fast_ratio(self) -> np.ndarray:
        """
        Fast charger ratio per zone.

        The station_information.csv uses TAZID (original Shenzhen survey IDs
        e.g. 559, 558) while time-series files use sequential zone IDs (102, 104).
        There is no direct join key between the two ID systems in this dataset.

        We therefore use the UrbanEV paper's published global ratio:
          2,056 fast chargers out of 18,061 total piles = 0.1138 ≈ 0.114

        This is applied uniformly across all zones as a conservative default.
        Per-zone estimation can be enabled if a zone-ID mapping becomes available.
        """
        return np.full(self.n_zones, 0.114, dtype=np.float32)

    def _build_neighbors(self) -> List[List[int]]:
        """
        Build K-nearest neighbour list per zone using adjacency + distance.
        Priority: adjacent zones first (adj=1), then by distance.
        Zones with fewer than K neighbours are padded to K using closest non-adjacent.
        """
        K = self.cfg.n_neighbors
        n = self.n_zones
        neighbors = []

        for i in range(n):
            adj_idx  = np.where(self.adj[i] > 0)[0].tolist()
            dist_i   = self.dist[i].copy()
            dist_i[i] = np.inf  # exclude self

            if len(adj_idx) >= K:
                # Sort adjacent by distance, take top K
                adj_idx = sorted(adj_idx, key=lambda j: dist_i[j])[:K]
            else:
                # Supplement with closest non-adjacent
                non_adj = np.argsort(dist_i)
                for j in non_adj:
                    if j not in adj_idx and j != i:
                        adj_idx.append(int(j))
                    if len(adj_idx) == K:
                        break

            neighbors.append(adj_idx[:K])

        return neighbors

    def _normalise_zone_series(
        self,
        arr: np.ndarray,    # (T, Z)
        fit_end: int,
    ) -> Tuple[np.ndarray, List[StandardScaler]]:
        """
        Fit StandardScaler on training portion for each zone independently.
        Per-zone normalisation is critical because occupancy distributions
        vary drastically across zones (CBD vs residential).
        """
        T, Z = arr.shape
        out      = np.zeros_like(arr, dtype=np.float32)
        scalers  = []
        for z in range(Z):
            sc = StandardScaler()
            sc.fit(arr[:fit_end, z:z+1])
            out[:, z] = sc.transform(arr[:, z:z+1]).ravel()
            scalers.append(sc)
        return out, scalers

    def build_features(self) -> "UrbanEVLoader":
        """
        Construct the full feature tensor (T, Z, F) and target arrays.

        Feature vector per zone per timestep (7 features):
          [0] occ_norm      — normalised occupancy
          [1] vol_norm      — normalised charging volume
          [2] dur_norm      — normalised session duration
          [3] ep_norm       — normalised electricity price
          [4] sp_norm       — normalised service price
          [5] fast_ratio    — fraction of fast chargers (static per zone)
          [6] pile_norm     — normalised pile count (static per zone)
        """
        T = len(self.timestamps)
        self.train_end = int(T * self.cfg.train_ratio)
        self.val_end   = int(T * (self.cfg.train_ratio + self.cfg.val_ratio))

        # ── Impute missing values (forward fill → backward fill per zone) ────
        occ_raw  = self._impute(self.occ).values.astype(np.float32)
        vol_r    = self._impute(self.vol).values.astype(np.float32)
        dur_raw  = self._impute(self.dur).values.astype(np.float32)
        ep_raw_  = self._impute(self.e_price).values.astype(np.float32)
        sp_raw_  = self._impute(self.s_price).values.astype(np.float32)

        # UrbanEV occupancy stores raw pile-usage COUNTS (e.g. 17.0), not a
        # 0-1 ratio. Convert to occupancy ratio by dividing by per-zone maximum
        # (= proxy for total piles available). This is the standard approach in
        # the UrbanEV literature when pile counts are not directly available.
        zone_max = occ_raw.max(axis=0, keepdims=True)   # (1, Z)
        zone_max = np.where(zone_max == 0, 1.0, zone_max)
        occ_r    = (occ_raw / zone_max).astype(np.float32)  # now in [0, 1]
        dur_r  = self._impute(self.dur).values.astype(np.float32)
        ep_r   = self._impute(self.e_price).values.astype(np.float32)
        sp_r   = self._impute(self.s_price).values.astype(np.float32)

        # Normalise per zone (fit scaler ONLY on training portion — no leakage)
        occ_n, self.scalers_occ = self._normalise_zone_series(occ_r,   self.train_end)
        vol_n, self.scalers_vol = self._normalise_zone_series(vol_r,   self.train_end)
        dur_n, _                = self._normalise_zone_series(dur_raw, self.train_end)
        ep_n,  _                = self._normalise_zone_series(ep_raw_, self.train_end)
        sp_n,  _                = self._normalise_zone_series(sp_raw_, self.train_end)

        # Static per-zone features (broadcast across T)
        self.fast_ratio = self._build_fast_ratio()    # (Z,) — global default 0.114
        fast_2d  = np.tile(self.fast_ratio, (T, 1))  # (T, Z)

        # Pile count per zone:
        # zone_info is indexed by TAZID (1066, 1068...) — a different numbering
        # system from sequential zone IDs in occupancy.csv (102, 104...).
        # No reliable per-zone mapping exists in this dataset release.
        # We derive a proxy pile count from the occupancy data itself:
        # max observed pile usage per zone ≈ total available piles.
        # (This is the standard approach in UrbanEV-based studies.)
        occ_for_piles = self._impute(self.occ).values.astype(np.float32)
        pile_proxy = occ_for_piles.max(axis=0)              # (Z,) — max per zone
        pile_proxy = np.where(pile_proxy == 0, 1.0, pile_proxy)
        pile_vals  = (pile_proxy - pile_proxy.mean()) / (pile_proxy.std() + 1e-8)
        pile_2d    = np.tile(pile_vals.astype(np.float32), (T, 1))  # (T, Z)

        # Stack feature tensor: (T, Z, 7)
        self.features = np.stack(
            [occ_n, vol_n, dur_n, ep_n, sp_n, fast_2d, pile_2d], axis=2
        )

        # Temporal features: (T, 6) — shared across zones
        self.temporal = self._build_temporal()

        # Raw targets (un-normalised occupancy ratio and volume)
        self.targets_occ_raw = occ_r    # (T, Z) — occupancy in [0,1]
        self.targets_vol_raw = vol_r    # (T, Z) — volume in kWh

        # Normalised targets for MTL model (StandardScaler per zone)
        self.targets_occ = occ_n
        self.targets_vol = vol_n

        # Spatial graph
        self.neighbors = self._build_neighbors()
        self.dist_norm = (self.dist / (self.dist.max() + 1e-8)).astype(np.float32)

        # Raw price arrays kept for RL reward calculation
        self.ep_raw = ep_raw_
        self.sp_raw = sp_raw_

        self.logger.info(
            f"Features: {self.features.shape}, "
            f"Targets: occ {self.targets_occ.shape}, vol {self.targets_vol.shape}"
        )
        return self

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 2: MULTI-FACETED DATASET LOADER
# Drop-in replacement for UrbanEVLoader
# ══════════════════════════════════════════════════════════════════════════════

class MultiFacetedLoader:
    """
    Loads ChargingRecords.csv and produces the identical attribute interface
    as UrbanEVLoader so every downstream component works without modification.

    Schema mapping
    ──────────────
    Zone      = unique Location (each location = one spatial zone / node)
    Occupancy = active session count per 1-hour bin per zone
                (session active at hour t iff StartDatetime <= t < EndDatetime)
                Normalised to [0,1] by per-zone maximum.
    Volume    = total Demand (energy) per 1-hour bin per zone
                (energy distributed proportionally across active slots)
    Duration  = mean Duration (minutes) per 1-hour bin per zone
    e_price   = time-of-day proxy: peak 08-20h=1.0, shoulder=0.7, off-peak=0.4
    s_price   = ChargerCompany-tier proxy: ranked [0.30 .. 0.80]
    fast_ratio = per zone fraction of events with ChargerType containing DC/FAST
    pile_norm  = per zone max-observed occupancy count (proxy for charger count)

    Graph
    ─────
    Zones placed on 1-D corridor with 5 km spacing + seeded noise.
    Adjacency = K nearest neighbours (symmetric).
    """

    def __init__(self, cfg: Config):
        self.cfg    = cfg
        self.logger = get_logger("DataLoader")
        # All attributes identical to UrbanEVLoader
        self.occ = self.vol = self.dur = self.e_price = self.s_price = None
        self.adj = self.dist = None
        self.zones      : List[str]        = None
        self.n_zones    : int              = 0
        self.timestamps : pd.DatetimeIndex = None
        self.features   : np.ndarray       = None  # (T, Z, 7)
        self.temporal   : np.ndarray       = None  # (T, 6)
        self.targets_occ: np.ndarray       = None  # (T, Z)
        self.targets_vol: np.ndarray       = None  # (T, Z)
        self.scalers_occ: List             = []
        self.scalers_vol: List             = []
        self.fast_ratio : np.ndarray       = None  # (Z,)
        self.neighbors  : List[List[int]]  = []
        self.dist_norm  : np.ndarray       = None  # (Z, Z)
        self.ep_raw     : np.ndarray       = None  # (T, Z)
        self.sp_raw     : np.ndarray       = None  # (T, Z)
        self.train_end  : int              = 0
        self.val_end    : int              = 0

    # ── Helpers (identical to UrbanEVLoader) ──────────────────────────────

    def _cyclical(self, v, period):
        r = 2 * np.pi * v / period
        return np.sin(r), np.cos(r)

    def _impute(self, df):
        return df.ffill().bfill().fillna(0.0)

    def _normalise_zone_series(self, arr, fit_end):
        T, Z = arr.shape
        out, sc_list = np.zeros_like(arr, dtype=np.float32), []
        for z in range(Z):
            sc = StandardScaler()
            sc.fit(arr[:fit_end, z:z+1])
            out[:, z] = sc.transform(arr[:, z:z+1]).ravel()
            sc_list.append(sc)
        return out, sc_list

    def _build_temporal(self):
        h = self.timestamps.hour.values.astype(float)
        d = self.timestamps.dayofweek.values.astype(float)
        m = (self.timestamps.month.values - 1).astype(float)
        sh, ch = self._cyclical(h, 24.0)
        sd, cd = self._cyclical(d,  7.0)
        sm, cm = self._cyclical(m, 12.0)
        return np.stack([sh, ch, sd, cd, sm, cm], axis=1).astype(np.float32)

    def _build_neighbors(self):
        K = self.cfg.n_neighbors
        result = []
        for i in range(self.n_zones):
            d_i = self.dist[i].copy(); d_i[i] = np.inf
            adj_idx = np.where(self.adj[i] > 0)[0].tolist()
            if len(adj_idx) >= K:
                adj_idx = sorted(adj_idx, key=lambda j: d_i[j])[:K]
            else:
                for j in np.argsort(d_i):
                    if j not in adj_idx and j != i:
                        adj_idx.append(int(j))
                    if len(adj_idx) == K:
                        break
            result.append(adj_idx[:K])
        return result

    # ── Session expansion ──────────────────────────────────────────────────

    def _expand_sessions(self, df, hourly_idx, zones):
        """Expand each session to every 1-hour slot it occupies."""
        n_t, n_z = len(hourly_idx), len(zones)
        zi_map   = {z: i for i, z in enumerate(zones)}
        occ_a    = np.zeros((n_t, n_z), dtype=np.float32)
        vol_a    = np.zeros((n_t, n_z), dtype=np.float32)
        dur_a    = np.zeros((n_t, n_z), dtype=np.float32)
        cnt_a    = np.zeros((n_t, n_z), dtype=np.float32)
        idx_ns   = hourly_idx.asi8   # int64 ns for searchsorted

        for _, row in df.iterrows():
            z = row["Location"]
            if z not in zi_map:
                continue
            zi = zi_map[z]
            s  = pd.Timestamp(row["StartDatetime"]).floor("H")
            e  = pd.Timestamp(row["EndDatetime"]).ceil("H")
            if e <= s:
                e = s + pd.Timedelta("1H")
            i_s = int(np.searchsorted(idx_ns, s.value, side="left"))
            i_e = int(np.searchsorted(idx_ns, e.value, side="left"))
            if i_s >= n_t:
                continue
            i_e = min(i_e, n_t)
            ns  = i_e - i_s
            if ns <= 0:
                continue
            occ_a[i_s:i_e, zi] += 1.0
            vol_a[i_s:i_e, zi] += row["Demand"] / ns
            dur_a[i_s:i_e, zi] += row["Duration_min"]
            cnt_a[i_s:i_e, zi] += 1.0

        safe     = np.where(cnt_a == 0, 1.0, cnt_a)
        dur_mean = dur_a / safe
        return (pd.DataFrame(occ_a, index=hourly_idx, columns=zones),
                pd.DataFrame(vol_a, index=hourly_idx, columns=zones),
                pd.DataFrame(dur_mean, index=hourly_idx, columns=zones))

    # ── load() ─────────────────────────────────────────────────────────────

    @staticmethod
    def _find_col(df: pd.DataFrame, candidates: List[str],
                  default_val: float = 0.0) -> pd.Series:
        """
        Return the first column from `candidates` found in df (case-insensitive,
        strips parentheses/underscores/spaces).  Raises a clear error if none found.
        """
        def _norm(s):
            import re as _re; return _re.sub(r"[\s_()]+", "", s.lower())

        col_map = {_norm(c): c for c in df.columns}
        for cand in candidates:
            key = _norm(cand)
            if key in col_map:
                return col_map[key]       # return actual column name in df
        # Last resort: return pd.Series of zeros rather than crashing
        return None

    def load(self) -> "MultiFacetedLoader":
        self.logger.info("Loading Multi-Faceted ChargingRecords dataset ...")

        csv_path = self.cfg.base_path
        if os.path.isdir(csv_path):
            import glob
            csvs = glob.glob(os.path.join(csv_path, "*.csv"))
            if csvs:
                csv_path = csvs[0]
                self.logger.info(f"  Auto-detected CSV: {os.path.basename(csv_path)}")
            else:
                raise FileNotFoundError(f"No CSV files found in {csv_path}")
        df = pd.read_csv(csv_path)

        # Log actual columns so any mismatch is immediately visible
        self.logger.info(f"  CSV columns: {list(df.columns)}")

        # ── Robust column mapping ─────────────────────────────────────────────
        # Multiple candidate names handle CSV variants across dataset versions.
        dur_col    = self._find_col(df, ["Duration (minutes)", "Duration_minutes",
                                         "Duration(minutes)", "Duration", "DurationMin"])
        demand_col = self._find_col(df, ["Demand (energy)", "Demand_energy",
                                         "Demand(energy)", "Demand", "Energy",
                                         "EnergyDemand", "kWh"])
        start_col  = self._find_col(df, ["StartDatetime", "Start_Datetime",
                                         "Start DateTime", "StartTime", "start"])
        end_col    = self._find_col(df, ["EndDatetime", "End_Datetime",
                                         "End DateTime", "EndTime", "end"])
        loc_col    = self._find_col(df, ["Location", "location", "Site",
                                         "StationLocation", "station_location"])
        comp_col   = self._find_col(df, ["ChargerCompany", "Company",
                                         "Operator", "Provider"])
        type_col   = self._find_col(df, ["ChargerType", "Charger_Type",
                                         "Type", "ChargerLevel"])

        if start_col is None or end_col is None:
            raise ValueError(
                f"Cannot find StartDatetime/EndDatetime columns. "
                f"Available: {list(df.columns)}"
            )
        if loc_col is None:
            raise ValueError(
                f"Cannot find Location column. Available: {list(df.columns)}"
            )

        # Normalise to standard internal names
        rename_map = {}
        if dur_col    and dur_col    != "Duration_min":  rename_map[dur_col]    = "Duration_min"
        if demand_col and demand_col != "Demand":         rename_map[demand_col] = "Demand"
        if start_col  and start_col  != "StartDatetime": rename_map[start_col]  = "StartDatetime"
        if end_col    and end_col    != "EndDatetime":    rename_map[end_col]    = "EndDatetime"
        if loc_col    and loc_col    != "Location":       rename_map[loc_col]    = "Location"
        if comp_col   and comp_col   != "ChargerCompany": rename_map[comp_col]   = "ChargerCompany"
        if type_col   and type_col   != "ChargerType":    rename_map[type_col]   = "ChargerType"

        if rename_map:
            self.logger.info(f"  Column renames: {rename_map}")
            df = df.rename(columns=rename_map)

        # Add missing optional columns with sensible defaults
        if "Duration_min" not in df.columns:
            self.logger.warning("  Duration column not found — defaulting to 30 min")
            df["Duration_min"] = 30.0
        if "Demand" not in df.columns:
            self.logger.warning("  Demand column not found — defaulting to 0")
            df["Demand"] = 0.0
        if "ChargerCompany" not in df.columns:
            df["ChargerCompany"] = "Unknown"
        if "ChargerType" not in df.columns:
            df["ChargerType"] = "AC"

        # Ensure string columns are actually strings (some CSVs have mixed types)
        for str_col in ["ChargerType", "ChargerCompany", "Location"]:
            if str_col in df.columns:
                df[str_col] = df[str_col].astype(str).replace("nan", "")

        # Parse and clean
        df["StartDatetime"] = pd.to_datetime(df["StartDatetime"], errors="coerce")
        df["EndDatetime"]   = pd.to_datetime(df["EndDatetime"],   errors="coerce")
        df = df.dropna(subset=["StartDatetime", "EndDatetime", "Location"])
        df["Duration_min"] = pd.to_numeric(df["Duration_min"], errors="coerce").fillna(0.0)
        df["Demand"]       = pd.to_numeric(df["Demand"],       errors="coerce").fillna(0.0)
        df = df[(df["Duration_min"] > 0) & (df["EndDatetime"] > df["StartDatetime"])].copy()

        zones = sorted(df["Location"].unique().tolist())
        self.n_zones = len(zones)
        self.logger.info(f"  Unique locations (zones): {self.n_zones}")

        t_min = df["StartDatetime"].min().floor("H")
        t_max = df["EndDatetime"].max().ceil("H")
        hourly_idx = pd.date_range(t_min, t_max, freq="H")
        self.logger.info(f"  Time: {t_min} to {t_max} ({len(hourly_idx)} hours)")

        self.logger.info("  Expanding sessions to hourly slots ...")
        occ_df, vol_df, dur_df = self._expand_sessions(df, hourly_idx, zones)

        # Electricity price proxy
        h_arr = hourly_idx.hour.values
        ep_1d = np.where((h_arr >= 8) & (h_arr < 20), 1.0,
                np.where((h_arr >= 6) & (h_arr < 22), 0.7, 0.4)).astype(np.float32)
        ep_2d = np.tile(ep_1d.reshape(-1, 1), (1, self.n_zones))

        # Service price proxy
        companies = sorted(df["ChargerCompany"].dropna().unique())
        n_c       = max(len(companies), 1)
        c_tier    = {c: 0.3 + 0.5 * (i / max(n_c-1, 1)) for i, c in enumerate(companies)}
        sp_1d = np.array([
            float(np.mean([c_tier.get(c, 0.55)
                           for c in df[df["Location"]==z]["ChargerCompany"].dropna().unique()])
                  ) if len(df[df["Location"]==z]) > 0 else 0.55
            for z in zones], dtype=np.float32)
        sp_2d = np.tile(sp_1d.reshape(1, -1), (len(hourly_idx), 1))

        self.occ     = occ_df
        self.vol     = vol_df
        self.dur     = dur_df
        self.e_price = pd.DataFrame(ep_2d, index=hourly_idx, columns=zones)
        self.s_price = pd.DataFrame(sp_2d, index=hourly_idx, columns=zones)

        # fast_ratio per zone
        self.fast_ratio = np.array([
            float(df[df["Location"]==z]["ChargerType"]
                  .astype(str).str.upper().str.contains("DC|FAST", na=False).sum()) /
            max(len(df[df["Location"]==z]), 1)
            for z in zones], dtype=np.float32)

        # Synthetic distance + adjacency
        rng  = np.random.default_rng(seed=42)
        pos  = np.arange(self.n_zones, dtype=np.float32) * 5.0
        pos += rng.uniform(-1.0, 1.0, self.n_zones).astype(np.float32)
        dist = np.abs(pos.reshape(-1, 1) - pos.reshape(1, -1)).astype(np.float32)
        np.fill_diagonal(dist, 0.0)
        K   = self.cfg.n_neighbors
        adj = np.zeros((self.n_zones, self.n_zones), dtype=np.float32)
        for i in range(self.n_zones):
            d_i = dist[i].copy(); d_i[i] = np.inf
            adj[i, np.argsort(d_i)[:K]] = 1.0
        adj = np.maximum(adj, adj.T)
        np.fill_diagonal(adj, 0.0)

        self.adj        = adj
        self.dist       = dist
        self.zones      = zones
        self.timestamps = hourly_idx
        self.logger.info(f"  Loaded: {len(hourly_idx)} timestamps x {self.n_zones} zones")
        return self

    # ── build_features() — identical logic to UrbanEVLoader ──────────────

    def build_features(self) -> "MultiFacetedLoader":
        T = len(self.timestamps)
        self.train_end = int(T * self.cfg.train_ratio)
        self.val_end   = int(T * (self.cfg.train_ratio + self.cfg.val_ratio))

        occ_raw = self._impute(self.occ).values.astype(np.float32)
        vol_r   = self._impute(self.vol).values.astype(np.float32)
        dur_raw = self._impute(self.dur).values.astype(np.float32)
        ep_raw  = self._impute(self.e_price).values.astype(np.float32)
        sp_raw  = self._impute(self.s_price).values.astype(np.float32)

        zone_max = occ_raw.max(axis=0, keepdims=True)
        zone_max = np.where(zone_max == 0, 1.0, zone_max)
        occ_r    = (occ_raw / zone_max).astype(np.float32)

        occ_n, self.scalers_occ = self._normalise_zone_series(occ_r,   self.train_end)
        vol_n, self.scalers_vol = self._normalise_zone_series(vol_r,   self.train_end)
        dur_n, _                = self._normalise_zone_series(dur_raw, self.train_end)
        ep_n,  _                = self._normalise_zone_series(ep_raw,  self.train_end)
        sp_n,  _                = self._normalise_zone_series(sp_raw,  self.train_end)

        fast_2d    = np.tile(self.fast_ratio, (T, 1))
        pile_proxy = occ_raw.max(axis=0).astype(np.float32) + 1.0
        pile_vals  = (pile_proxy - pile_proxy.mean()) / (pile_proxy.std() + 1e-8)
        pile_2d    = np.tile(pile_vals, (T, 1))

        self.features    = np.stack(
            [occ_n, vol_n, dur_n, ep_n, sp_n, fast_2d, pile_2d], axis=2)
        self.temporal    = self._build_temporal()
        self.targets_occ = occ_n
        self.targets_vol = vol_n
        self.neighbors   = self._build_neighbors()
        self.dist_norm   = (self.dist / (self.dist.max() + 1e-8)).astype(np.float32)
        self.ep_raw      = ep_raw
        self.sp_raw      = sp_raw

        self.logger.info(
            f"Features: {self.features.shape}, "
            f"Targets: occ {self.targets_occ.shape}, vol {self.targets_vol.shape}")
        return self

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 2: SAUDI EVCS DATASET LOADER
# Drop-in replacement for UrbanEVLoader
# Reads the pre-built saudi_ev_unified.csv (2160h × 9 EVCS × 7 features)
# ══════════════════════════════════════════════════════════════════════════════

class SaudiEVCSLoader:
    """
    Loads the Saudi Arabia Al Jouf EVCS dataset and produces the identical
    attribute interface as UrbanEVLoader so every downstream component
    (MTL model, RL environment, Visualiser) works without modification.

    Input files (all in cfg.base_path directory):
      saudi_ev_unified.csv    — 2160 hourly rows × 9 EVCS × 7 features
      saudi_evcs_distance.csv — 9×9 inter-EVCS distance matrix (km)
      saudi_evcs_adj.csv      — 9×9 K-NN adjacency matrix

    Schema mapping
    ──────────────
    Zones     = 9 EVCS stations (EVCS_1 .. EVCS_9) on Al Jouf highways
    Occupancy = active charging sessions per hour per EVCS
                (normalised to [0,1] by per-zone maximum)
    Volume    = total kWh demand per hour per EVCS
    Duration  = mean session duration (minutes) per hour per EVCS
    e_price   = time-of-day electricity price proxy (SAR/kWh)
    s_price   = station-specific service price proxy
    Extra     = renewable_kw (solar/wind), ess_soc (battery storage)

    Feature vector per EVCS per hour (7 features — same as UrbanEV):
      [0] occ_norm       [1] vol_norm       [2] dur_norm
      [3] ep_norm        [4] sp_norm        [5] fast_ratio (static)
      [6] pile_norm (static)
    """

    def __init__(self, cfg: Config):
        self.cfg    = cfg
        self.logger = get_logger("DataLoader")
        # All public attributes identical to UrbanEVLoader
        self.occ = self.vol = self.dur = self.e_price = self.s_price = None
        self.adj         : np.ndarray           = None
        self.dist        : np.ndarray           = None
        self.zones       : List[str]            = None
        self.n_zones     : int                  = 0
        self.timestamps  : pd.DatetimeIndex     = None
        self.features    : np.ndarray           = None  # (T, Z, 7)
        self.temporal    : np.ndarray           = None  # (T, 6)
        self.targets_occ : np.ndarray           = None
        self.targets_vol : np.ndarray           = None
        self.scalers_occ : List                 = []
        self.scalers_vol : List                 = []
        self.fast_ratio  : np.ndarray           = None
        self.neighbors   : List[List[int]]      = []
        self.dist_norm   : np.ndarray           = None
        self.ep_raw      : np.ndarray           = None
        self.sp_raw      : np.ndarray           = None
        self.train_end   : int                  = 0
        self.val_end     : int                  = 0

    # ── Helpers ───────────────────────────────────────────────────────────

    def _cyclical(self, v, period):
        r = 2 * np.pi * v / period
        return np.sin(r), np.cos(r)

    def _impute(self, df):
        return df.ffill().bfill().fillna(0.0)

    def _normalise_zone_series(self, arr, fit_end):
        T, Z = arr.shape
        out, sc_list = np.zeros_like(arr, dtype=np.float32), []
        for z in range(Z):
            sc = StandardScaler()
            sc.fit(arr[:fit_end, z:z+1])
            out[:, z] = sc.transform(arr[:, z:z+1]).ravel()
            sc_list.append(sc)
        return out, sc_list

    def _build_temporal(self):
        h = self.timestamps.hour.values.astype(float)
        d = self.timestamps.dayofweek.values.astype(float)
        m = (self.timestamps.month.values - 1).astype(float)
        sh, ch = self._cyclical(h, 24.0)
        sd, cd = self._cyclical(d,  7.0)
        sm, cm = self._cyclical(m, 12.0)
        return np.stack([sh, ch, sd, cd, sm, cm], axis=1).astype(np.float32)

    def _build_neighbors(self):
        K = self.cfg.n_neighbors
        result = []
        for i in range(self.n_zones):
            d_i = self.dist[i].copy(); d_i[i] = np.inf
            adj_idx = np.where(self.adj[i] > 0)[0].tolist()
            if len(adj_idx) >= K:
                adj_idx = sorted(adj_idx, key=lambda j: d_i[j])[:K]
            else:
                for j in np.argsort(d_i):
                    if j not in adj_idx and j != i:
                        adj_idx.append(int(j))
                    if len(adj_idx) == K:
                        break
            result.append(adj_idx[:K])
        return result

    # ── load() ────────────────────────────────────────────────────────────

    def load(self) -> "SaudiEVCSLoader":
        self.logger.info("Loading Saudi Arabia Al Jouf EVCS dataset ...")
        base = self.cfg.base_path

        # Detect whether base_path is a directory or a CSV file
        if os.path.isfile(base) and base.endswith(".csv"):
            csv_path  = base
            base_dir  = os.path.dirname(base)
        else:
            csv_path  = os.path.join(base, "saudi_ev_unified.csv")
            base_dir  = base

        df = pd.read_csv(csv_path)
        self.logger.info(f"  Loaded unified CSV: {df.shape}")
        self.logger.info(f"  Columns: {list(df.columns[:8])} ...")

        # Parse timestamps
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        timestamps = df["timestamp"]

        # Detect zone names from column pattern: EVCS_N_occupancy
        import re as _re
        zone_cols = sorted(set(
            _re.match(r"(EVCS_\d+)_", c).group(1)
            for c in df.columns if _re.match(r"EVCS_\d+_", c)
        ), key=lambda x: int(x.split("_")[1]))

        self.zones   = zone_cols
        self.n_zones = len(zone_cols)
        self.logger.info(f"  Zones: {self.n_zones} — {zone_cols}")

        # Extract per-zone time-series
        T = len(timestamps)
        def _extract(suffix):
            cols = [f"{z}_{suffix}" for z in zone_cols]
            return df[cols].values.astype(np.float32)

        occ_raw  = _extract("occupancy")
        vol_raw  = _extract("volume_kwh")
        dur_raw  = _extract("duration_min")
        ep_raw   = _extract("e_price")
        sp_raw   = _extract("s_price")

        self.occ     = pd.DataFrame(occ_raw, index=timestamps, columns=zone_cols)
        self.vol     = pd.DataFrame(vol_raw, index=timestamps, columns=zone_cols)
        self.dur     = pd.DataFrame(dur_raw, index=timestamps, columns=zone_cols)
        self.e_price = pd.DataFrame(ep_raw,  index=timestamps, columns=zone_cols)
        self.s_price = pd.DataFrame(sp_raw,  index=timestamps, columns=zone_cols)
        self.timestamps = pd.DatetimeIndex(timestamps)

        # Load distance + adjacency matrices
        dist_path = os.path.join(base_dir, "saudi_evcs_distance.csv")
        adj_path  = os.path.join(base_dir, "saudi_evcs_adj.csv")

        if os.path.exists(dist_path):
            self.dist = pd.read_csv(dist_path).values.astype(np.float32)
            self.adj  = pd.read_csv(adj_path).values.astype(np.float32)
            self.logger.info(f"  Distance matrix: {self.dist.shape}")
        else:
            # Synthetic fallback
            self.logger.warning("  Distance/adj files not found — using synthetic")
            pos = np.arange(self.n_zones, dtype=np.float32) * 50.0
            self.dist = np.abs(pos.reshape(-1,1)-pos.reshape(1,-1))
            np.fill_diagonal(self.dist, 0)
            K = min(self.cfg.n_neighbors, self.n_zones - 1)
            self.adj = np.zeros((self.n_zones, self.n_zones), dtype=np.float32)
            for i in range(self.n_zones):
                di = self.dist[i].copy(); di[i] = np.inf
                self.adj[i, np.argsort(di)[:K]] = 1
            self.adj = np.maximum(self.adj, self.adj.T)
            np.fill_diagonal(self.adj, 0)

        # Fast ratio: Saudi EVCS have both L3 and L2 — L3 fraction ≈ 0.5
        # (4 L3 sockets + 4 L2 sockets per EVCS from PDF)
        self.fast_ratio = np.full(self.n_zones, 0.50, dtype=np.float32)

        self.logger.info(f"  Loaded: {T} timestamps × {self.n_zones} EVCS")
        return self

    # ── build_features() ──────────────────────────────────────────────────

    def build_features(self) -> "SaudiEVCSLoader":
        T = len(self.timestamps)
        self.train_end = int(T * self.cfg.train_ratio)
        self.val_end   = int(T * (self.cfg.train_ratio + self.cfg.val_ratio))

        occ_raw = self._impute(self.occ).values.astype(np.float32)
        vol_r   = self._impute(self.vol).values.astype(np.float32)
        dur_raw = self._impute(self.dur).values.astype(np.float32)
        ep_raw  = self._impute(self.e_price).values.astype(np.float32)
        sp_raw  = self._impute(self.s_price).values.astype(np.float32)

        # Normalise occupancy to [0,1]
        zone_max = occ_raw.max(axis=0, keepdims=True)
        zone_max = np.where(zone_max == 0, 1.0, zone_max)
        occ_r    = (occ_raw / zone_max).astype(np.float32)

        # Normalise all per zone (scaler fit on train only)
        occ_n, self.scalers_occ = self._normalise_zone_series(occ_r,   self.train_end)
        vol_n, self.scalers_vol = self._normalise_zone_series(vol_r,   self.train_end)
        dur_n, _                = self._normalise_zone_series(dur_raw, self.train_end)
        ep_n,  _                = self._normalise_zone_series(ep_raw,  self.train_end)
        sp_n,  _                = self._normalise_zone_series(sp_raw,  self.train_end)

        fast_2d = np.tile(self.fast_ratio, (T, 1))

        # Pile proxy = max observed occupancy per EVCS
        pile_proxy = occ_raw.max(axis=0).astype(np.float32) + 1.0
        pile_vals  = (pile_proxy - pile_proxy.mean()) / (pile_proxy.std() + 1e-8)
        pile_2d    = np.tile(pile_vals, (T, 1))

        self.features    = np.stack(
            [occ_n, vol_n, dur_n, ep_n, sp_n, fast_2d, pile_2d], axis=2)
        self.temporal    = self._build_temporal()
        self.targets_occ = occ_n
        self.targets_vol = vol_n
        self.neighbors   = self._build_neighbors()
        self.dist_norm   = (self.dist / (self.dist.max() + 1e-8)).astype(np.float32)
        self.ep_raw      = ep_raw
        self.sp_raw      = sp_raw

        self.logger.info(
            f"Features: {self.features.shape}, "
            f"Targets: occ {self.targets_occ.shape}, vol {self.targets_vol.shape}")
        return self

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 3: MTL SLIDING-WINDOW DATASET
# ══════════════════════════════════════════════════════════════════════════════

class MTLWindowDataset(Dataset):
    """
    Sliding-window PyTorch Dataset for multi-zone, multi-task forecasting.

    Each sample: past W timesteps → future H timesteps
    Input shape:  (W, Z, F_zone) + (W, F_temporal)
    Target shape: (H, Z) for each task (occupancy, volume)

    Design notes:
      - Samples are constructed lazily (no pre-allocation) for memory efficiency
      - train/val/test slicing is done at construction time (no leakage)
    """

    def __init__(
        self,
        loader: object,
        split: str,          # "train" | "val" | "test"
        horizon: int = 1,    # prediction horizon in hours
    ):
        super().__init__()
        W = loader.cfg.window_size
        H = horizon

        # Determine index range for this split
        if split == "train":
            start, end = 0, loader.train_end
        elif split == "val":
            start, end = loader.train_end, loader.val_end
        else:
            start, end = loader.val_end, len(loader.timestamps)

        # Valid sample indices: need W past + H future
        self.indices = list(range(start + W, end - H + 1))

        self.features  = loader.features   # (T, Z, F)
        self.temporal  = loader.temporal   # (T, 6)
        self.t_occ     = loader.targets_occ  # (T, Z)
        self.t_vol     = loader.targets_vol  # (T, Z)
        self.W, self.H = W, H

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        t = self.indices[idx]

        x_zone = self.features[t - self.W : t]            # (W, Z, F)
        x_time = self.temporal[t - self.W : t]            # (W, 6)
        y_occ  = self.t_occ[t : t + self.H]               # (H, Z)
        y_vol  = self.t_vol[t : t + self.H]               # (H, Z)

        return {
            "x_zone": torch.from_numpy(x_zone),           # float32
            "x_time": torch.from_numpy(x_time),
            "y_occ":  torch.from_numpy(y_occ),
            "y_vol":  torch.from_numpy(y_vol),
        }