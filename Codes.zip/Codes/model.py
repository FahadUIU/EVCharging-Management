"""
model.py — Model
=================
Unified RL-MTL-LLM EV Charging Framework.
"""
import random
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.optim import Adam
from torch.optim.lr_scheduler import ExponentialLR
from sklearn.metrics import mean_squared_error
from scipy.stats import pearsonr

import gymnasium as gym
from gymnasium import spaces
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv

# ─── Language Models ─────────────────────────────────────────────────────────
# Safe GPT-2 import with version-mismatch fallback
try:
    from transformers import GPT2LMHeadModel, GPT2Tokenizer, logging as hf_logging
    HF_AVAILABLE = True
    hf_logging.set_verbosity_error()
except (ImportError, ModuleNotFoundError, AttributeError) as _hf_err:
    HF_AVAILABLE = False
    print(f"[WARNING] GPT-2 unavailable: {_hf_err}")
    print("[WARNING] LLM will use rule-based explanations instead.")
    class _Stub:
        @classmethod
        def from_pretrained(cls,*a,**kw): return cls()
        def eval(self): return self
        def to(self,d): return self
        def generate(self,**kw):
            import torch; return torch.zeros(1,10,dtype=torch.long)
        pad_token="<|endoftext|>"; eos_token_id=50256
        def __call__(self,text,**kw):
            import types,torch
            t=types.SimpleNamespace()
            t.input_ids=torch.zeros(1,10,dtype=torch.long)
            return t
    GPT2Tokenizer=_Stub; GPT2LMHeadModel=_Stub
    class hf_logging:
        @staticmethod
        def set_verbosity_error(): pass

from data_preprocessing import Config, get_logger, MTLWindowDataset


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 4: MODEL ARCHITECTURES — 5 Backbone Variants
# All share the same interface: forward(x) -> (B, W, feat_dim)
# ══════════════════════════════════════════════════════════════════════════════

# ── Backbone 1: LSTM (existing, unchanged) ────────────────────────────────────

class SharedLSTM(nn.Module):
    """Single/multi-layer LSTM backbone."""
    def __init__(self, in_dim: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        self.lstm = nn.LSTM(in_dim, hidden, n_layers, batch_first=True,
                            dropout=dropout if n_layers > 1 else 0.0)
        self.out_dim = hidden

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out, _ = self.lstm(x)
        return out


# ── Backbone 2: LSTM + Lightweight Transformer Encoder ────────────────────────

class SharedLSTMTransformer(nn.Module):
    """
    LSTM → single-layer Transformer encoder → FC + Dropout.

    Architecture:
      1. Single LSTM layer captures temporal dependencies
      2. One TransformerEncoderLayer with 2-head attention captures
         global dependencies without over-parameterising
      3. FC + Dropout refine the representation

    Design rationale:
      - Single encoder block keeps parameter count low
      - 2-head attention is sufficient for 12-step windows
      - Layer norm is pre-norm (more stable for shallow transformers)
    """
    def __init__(self, in_dim: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        # 1. Single LSTM layer
        self.lstm = nn.LSTM(in_dim, hidden, num_layers=1,
                            batch_first=True, dropout=0.0)

        # 2. Lightweight Transformer encoder (single block, 2-head)
        n_heads = 2
        # hidden must be divisible by n_heads
        tf_dim = hidden if hidden % n_heads == 0 else (hidden // n_heads + 1) * n_heads
        self.proj_in = nn.Linear(hidden, tf_dim) if tf_dim != hidden else nn.Identity()
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=tf_dim, nhead=n_heads,
            dim_feedforward=tf_dim * 2,  # compact FF
            dropout=dropout, batch_first=True,
            norm_first=True,  # pre-norm for stability
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=1)

        # 3. FC + Dropout
        self.fc      = nn.Linear(tf_dim, hidden)
        self.act     = nn.GELU()
        self.dropout = nn.Dropout(dropout)
        self.out_dim = hidden

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, W, in_dim)
        h_lstm, _ = self.lstm(x)           # (B, W, hidden)
        h_proj    = self.proj_in(h_lstm)    # (B, W, tf_dim)
        h_tf      = self.transformer(h_proj)  # (B, W, tf_dim)
        h_fc      = self.dropout(self.act(self.fc(h_tf)))  # (B, W, hidden)
        return h_fc


# ── Backbone 3: Bidirectional LSTM ────────────────────────────────────────────

class SharedBiLSTM(nn.Module):
    """
    Bidirectional LSTM: captures both past and future context.
    Output projected to hidden_dim to maintain consistent interface.
    """
    def __init__(self, in_dim: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        self.lstm = nn.LSTM(in_dim, hidden, n_layers, batch_first=True,
                            bidirectional=True,
                            dropout=dropout if n_layers > 1 else 0.0)
        self.proj = nn.Linear(hidden * 2, hidden)  # 2× for bidirectional
        self.out_dim = hidden

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out, _ = self.lstm(x)       # (B, W, hidden*2)
        return self.proj(out)       # (B, W, hidden)


# ── Backbone 4: GRU ──────────────────────────────────────────────────────────

class SharedGRU(nn.Module):
    """
    GRU backbone: fewer parameters than LSTM, faster training.
    Often competitive on shorter sequences.
    """
    def __init__(self, in_dim: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        self.gru = nn.GRU(in_dim, hidden, n_layers, batch_first=True,
                          dropout=dropout if n_layers > 1 else 0.0)
        self.out_dim = hidden

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out, _ = self.gru(x)
        return out


# ── Backbone 5: TCN (existing, unchanged) ─────────────────────────────────────

class CausalConvBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, kernel: int, dilation: int):
        super().__init__()
        pad = (kernel - 1) * dilation
        self.conv = nn.Conv1d(in_ch, out_ch, kernel, dilation=dilation, padding=pad)
        self.norm = nn.BatchNorm1d(out_ch)
        self.act  = nn.GELU()
        self.drop = nn.Dropout(0.1)
        self.proj = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.conv(x)[..., :x.size(-1)]
        out = self.drop(self.act(self.norm(out)))
        return out + self.proj(x)


class SharedTCN(nn.Module):
    def __init__(self, in_dim: int, channels: List[int], dilations: List[int], kernel: int):
        super().__init__()
        layers, prev_ch = [], in_dim
        for ch, d in zip(channels, dilations):
            layers.append(CausalConvBlock(prev_ch, ch, kernel, d))
            prev_ch = ch
        self.net = nn.Sequential(*layers)
        self.out_dim = channels[-1]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.permute(0, 2, 1)
        return self.net(x).permute(0, 2, 1)


# ── Backbone factory ──────────────────────────────────────────────────────────

BACKBONE_REGISTRY = {
    "LSTM":             SharedLSTM,
    "LSTM-Transformer": SharedLSTMTransformer,
    "BiLSTM":           SharedBiLSTM,
    "GRU":              SharedGRU,
}


def build_backbone(cfg: Config, in_dim: int) -> nn.Module:
    """Construct backbone from config.backbone string."""
    name = cfg.backbone
    if name == "TCN":
        return SharedTCN(in_dim, cfg.tcn_channels, cfg.tcn_dilations, cfg.tcn_kernel_size)
    if name in BACKBONE_REGISTRY:
        return BACKBONE_REGISTRY[name](in_dim, cfg.hidden_dim, cfg.num_layers, cfg.dropout)
    raise ValueError(f"Unknown backbone: {name}. Choose from: {list(BACKBONE_REGISTRY) + ['TCN']}")


# ── MTL Forecaster (unified — supports all 5 backbones) ──────────────────────

class MTLForecaster(nn.Module):
    """
    Multi-Task Learning forecaster with configurable backbone.

    Supported backbones (cfg.backbone):
      "LSTM"              — standard LSTM
      "LSTM-Transformer"  — LSTM + single-layer Transformer encoder
      "BiLSTM"            — bidirectional LSTM
      "GRU"               — Gated Recurrent Unit
      "TCN"               — Temporal Convolutional Network

    All backbones are wrapped identically:
      Zone embedding → input projection → backbone → task heads
    """

    def __init__(self, cfg: Config, n_zones: int, horizon: int):
        super().__init__()
        self.cfg     = cfg
        self.n_zones = n_zones
        self.horizon = horizon
        F = cfg.n_zone_features
        E = cfg.embedding_dim
        T = cfg.n_temporal_feats
        H = cfg.hidden_dim

        self.zone_emb = nn.Embedding(n_zones, E)
        in_dim = F + T + E

        # Build backbone from config
        self.backbone = build_backbone(cfg, in_dim)
        feat_dim = self.backbone.out_dim

        def _head(in_f, out_f):
            return nn.Sequential(
                nn.Linear(in_f, 128), nn.GELU(), nn.Dropout(cfg.dropout),
                nn.Linear(128, 64),   nn.GELU(), nn.Dropout(cfg.dropout),
                nn.Linear(64, out_f),
            )

        self.head_occ = _head(feat_dim, horizon)
        self.head_vol = _head(feat_dim, horizon)
        self.register_buffer("w_occ", torch.tensor(0.5))
        self.register_buffer("w_vol", torch.tensor(0.5))
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.LSTM, nn.GRU)):
                for name, p in m.named_parameters():
                    if "weight" in name: nn.init.orthogonal_(p)
                    elif "bias" in name: nn.init.zeros_(p)

    def forward(self, x_zone, x_time, zone_chunk=32):
        B, W, Z, F_feat = x_zone.shape
        zone_ids   = torch.arange(Z, device=x_zone.device)
        emb        = self.zone_emb(zone_ids)
        emb_exp    = emb.unsqueeze(0).unsqueeze(0).expand(B, W, Z, -1)
        x_time_exp = x_time.unsqueeze(2).expand(B, W, Z, -1)
        x_full     = torch.cat([x_zone, x_time_exp, emb_exp], dim=-1)

        occ_chunks, vol_chunks = [], []
        for z_s in range(0, Z, zone_chunk):
            z_e    = min(z_s + zone_chunk, Z)
            Zc     = z_e - z_s
            x_flat = x_full[:, :, z_s:z_e, :].permute(0, 2, 1, 3).reshape(B * Zc, W, -1)
            h_flat = self.backbone(x_flat)
            h_last = h_flat[:, -1, :]
            occ_chunks.append(self.head_occ(h_last).view(B, Zc, self.horizon))
            vol_chunks.append(self.head_vol(h_last).view(B, Zc, self.horizon))

        return torch.cat(occ_chunks, dim=1), torch.cat(vol_chunks, dim=1)

    def compute_loss(self, pred_occ, pred_vol, y_occ, y_vol):
        y_occ_t = y_occ.permute(0, 2, 1)
        y_vol_t = y_vol.permute(0, 2, 1)
        L_occ = F.mse_loss(pred_occ, y_occ_t)
        L_vol = F.mse_loss(pred_vol, y_vol_t)
        return self.w_occ * L_occ + self.w_vol * L_vol, L_occ, L_vol

    def update_weights(self, val_occ, val_vol):
        lo = torch.log1p(torch.tensor(val_occ))
        lv = torch.log1p(torch.tensor(val_vol))
        total = lo + lv + 1e-8
        self.w_occ = lo / total
        self.w_vol = lv / total


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 5: MTL TRAINER & EVALUATOR
# ══════════════════════════════════════════════════════════════════════════════

class MTLTrainer:
    """
    Training loop for the MTL forecaster with:
      - Gradient clipping (prevents exploding gradients in LSTM)
      - Exponential LR decay (smooth convergence)
      - Early stopping (prevents overfitting on 6-month dataset)
      - Best-model checkpointing (based on val RMSE for occupancy)
      - Dynamic task weight update each epoch
    """

    def __init__(
        self,
        model: "MTLForecaster",
        loader: object,
        cfg:        Config,
        horizon:    int = 1,
    ):
        self.model   = model.to(cfg.device)
        self.loader  = loader
        self.cfg     = cfg
        self.horizon = horizon
        self.device  = cfg.device
        self.logger  = get_logger(f"MTLTrainer[H={horizon}]")
        self.save_dir = Path(cfg.save_dir) / "mtl"
        self.save_dir.mkdir(parents=True, exist_ok=True)

        self.optimiser = Adam(model.parameters(), lr=cfg.learning_rate)
        self.scheduler = ExponentialLR(
            self.optimiser,
            gamma=cfg.lr_decay_rate ** (cfg.learning_rate / cfg.lr_decay_steps),
        )

        # History for plotting
        self.history: Dict[str, List[float]] = defaultdict(list)
        self.best_val_rmse = float("inf")
        self.best_epoch    = 0
        self.patience_ctr  = 0

        # Mixed precision — halves activation memory on T4/A100
        # Only enabled when training on CUDA; CPU training uses fp32
        self.use_amp   = (cfg.device == "cuda")
        # torch.amp.GradScaler is the non-deprecated API in PyTorch 2.x
        self.scaler = (
            torch.amp.GradScaler("cuda")
            if self.use_amp else torch.amp.GradScaler("cpu")
        )
        if self.use_amp:
            self.logger.info("Mixed precision (AMP) enabled — fp16 activations")

    def _make_loader(self, split: str) -> DataLoader:
        ds = MTLWindowDataset(self.loader, split, self.horizon)
        return DataLoader(
            ds,
            batch_size = self.cfg.batch_size,
            shuffle    = (split == "train"),
            num_workers= 0,
            pin_memory = (self.device == "cuda"),
            drop_last  = (split == "train"),
        )

    def _step(self, batch: Dict[str, torch.Tensor], train: bool = True):
        x_z  = batch["x_zone"].to(self.device)  # (B, W, Z, F)
        x_t  = batch["x_time"].to(self.device)  # (B, W, 6)
        y_o  = batch["y_occ"].to(self.device)
        y_v  = batch["y_vol"].to(self.device)

        # Mixed-precision forward pass (fp16 on CUDA, fp32 on CPU)
        with torch.set_grad_enabled(train):
            with torch.amp.autocast("cuda", enabled=self.use_amp):
                pred_occ, pred_vol = self.model(
                    x_z, x_t,
                    zone_chunk=self.cfg.zone_chunk,
                )
                loss, l_o, l_v = self.model.compute_loss(
                    pred_occ, pred_vol, y_o, y_v
                )

        if train:
            self.optimiser.zero_grad()
            # Scaled backward pass prevents fp16 underflow
            self.scaler.scale(loss).backward()
            self.scaler.unscale_(self.optimiser)
            nn.utils.clip_grad_norm_(
                self.model.parameters(), self.cfg.grad_clip_norm
            )
            self.scaler.step(self.optimiser)
            self.scaler.update()

        return loss.item(), l_o.item(), l_v.item(), pred_occ, pred_vol, y_o, y_v

    def train(self) -> None:
        train_dl = self._make_loader("train")
        val_dl   = self._make_loader("val")

        self.logger.info(
            f"Training MTL (horizon={self.horizon}h) | "
            f"device={self.device} | backbone={self.cfg.backbone}"
        )

        for epoch in range(1, self.cfg.max_epochs + 1):
            # ── Train ──────────────────────────────────────────────────────
            self.model.train()
            train_loss = 0.0
            for batch in train_dl:
                l, _, _, _, _, _, _ = self._step(batch, train=True)
                train_loss += l
            train_loss /= len(train_dl)
            self.scheduler.step()

            # ── Validate ────────────────────────────────────────────────────
            self.model.eval()
            val_preds_occ, val_preds_vol = [], []
            val_trues_occ, val_trues_vol = [], []
            val_loss = 0.0

            for batch in val_dl:
                l, l_o, l_v, po, pv, yo, yv = self._step(batch, train=False)
                val_loss += l
                # Collect 1-step predictions for metrics
                val_preds_occ.append(po.detach().cpu()[:, :, 0].numpy())
                val_preds_vol.append(pv.detach().cpu()[:, :, 0].numpy())
                val_trues_occ.append(yo.detach().cpu()[:, 0, :].numpy())
                val_trues_vol.append(yv.detach().cpu()[:, 0, :].numpy())

            val_loss /= len(val_dl)
            po_all = np.concatenate(val_preds_occ, axis=0).ravel()
            pv_all = np.concatenate(val_preds_vol, axis=0).ravel()
            to_all = np.concatenate(val_trues_occ, axis=0).ravel()
            tv_all = np.concatenate(val_trues_vol, axis=0).ravel()

            val_rmse_occ = float(np.sqrt(mean_squared_error(to_all, po_all)))
            val_rmse_vol = float(np.sqrt(mean_squared_error(tv_all, pv_all)))

            # Update dynamic weights
            self.model.update_weights(val_rmse_occ, val_rmse_vol)

            # Record history
            self.history["train_loss"].append(train_loss)
            self.history["val_loss"].append(val_loss)
            self.history["val_rmse_occ"].append(val_rmse_occ)
            self.history["val_rmse_vol"].append(val_rmse_vol)
            self.history["w_occ"].append(float(self.model.w_occ))
            self.history["w_vol"].append(float(self.model.w_vol))

            # ── Early stopping & checkpointing ──────────────────────────────
            if val_rmse_occ < self.best_val_rmse:
                self.best_val_rmse = val_rmse_occ
                self.best_epoch    = epoch
                self.patience_ctr  = 0
                ckpt_path = self.save_dir / f"best_model_H{self.horizon}.pt"
                torch.save(self.model.state_dict(), ckpt_path)
            else:
                self.patience_ctr += 1

            if epoch % 10 == 0 or self.patience_ctr == 0:
                self.logger.info(
                    f"Epoch {epoch:03d} | "
                    f"train={train_loss:.4f} | val={val_loss:.4f} | "
                    f"rmse_occ={val_rmse_occ:.4f} | rmse_vol={val_rmse_vol:.4f} | "
                    f"w=({float(self.model.w_occ):.2f},{float(self.model.w_vol):.2f})"
                )

            if self.patience_ctr >= self.cfg.early_stopping_patience:
                self.logger.info(
                    f"Early stopping at epoch {epoch} "
                    f"(best={self.best_val_rmse:.4f} at epoch {self.best_epoch})"
                )
                break

        # Reload best weights
        ckpt_path = self.save_dir / f"best_model_H{self.horizon}.pt"
        self.model.load_state_dict(torch.load(ckpt_path, map_location=self.device))
        self.logger.info(f"Best model reloaded from epoch {self.best_epoch}")

    def evaluate(self, split: str = "test") -> Dict[str, float]:
        """
        Full evaluation on a given split.
        Returns comprehensive regression metrics for both tasks.
        """
        # Deferred import: evaluation.py imports MTLTrainer from this module,
        # so this import is done at call time (not at module load) to avoid
        # a circular import between model.py and evaluation.py.
        from evaluation import compute_regression_metrics

        self.model.eval()
        dl = self._make_loader(split)

        all_po, all_pv, all_to, all_tv = [], [], [], []

        with torch.no_grad():
            for batch in dl:
                x_z = batch["x_zone"].to(self.device)
                x_t = batch["x_time"].to(self.device)
                y_o = batch["y_occ"]
                y_v = batch["y_vol"]

                with torch.amp.autocast("cuda", enabled=self.use_amp):
                    po, pv = self.model(
                        x_z, x_t,
                        zone_chunk=self.cfg.zone_chunk,
                    )
                # .float() ensures fp32 for numpy conversion after fp16 forward
                all_po.append(po.float().cpu()[:, :, 0].numpy())
                all_pv.append(pv.float().cpu()[:, :, 0].numpy())
                all_to.append(y_o.cpu()[:, 0, :].numpy())
                all_tv.append(y_v.cpu()[:, 0, :].numpy())

        po_all = np.concatenate(all_po, 0).ravel()
        pv_all = np.concatenate(all_pv, 0).ravel()
        to_all = np.concatenate(all_to, 0).ravel()
        tv_all = np.concatenate(all_tv, 0).ravel()

        metrics = {}
        metrics.update(compute_regression_metrics(to_all, po_all, "OCC"))
        metrics.update(compute_regression_metrics(tv_all, pv_all, "VOL"))
        return metrics

    def generate_forecasts(self, split: str = "test") -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate forecasts for ALL zones in a split.
        Returns arrays of shape (N_samples, Z) for use in RL environment.
        """
        self.model.eval()
        dl = self._make_loader(split)
        po_list, pv_list = [], []

        use_amp = (next(self.model.parameters()).device.type == "cuda")
        with torch.no_grad():
            for batch in dl:
                x_z = batch["x_zone"].to(self.device)
                x_t = batch["x_time"].to(self.device)
                with torch.amp.autocast("cuda", enabled=use_amp):
                    po, pv = self.model(
                        x_z, x_t,
                        zone_chunk=self.cfg.zone_chunk,
                    )
                po_list.append(po.float().cpu().numpy()[:, :, 0])
                pv_list.append(pv.float().cpu().numpy()[:, :, 0])

        return np.concatenate(po_list, 0), np.concatenate(pv_list, 0)

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 6: REINFORCEMENT LEARNING ENVIRONMENT
# ══════════════════════════════════════════════════════════════════════════════

class SatisfactionScorer:
    """
    Composite driver satisfaction score ∈ [0, 1] (O6).

    Components:
      s_wait    — based on predicted occupancy at recommended zone
      s_cost    — based on combined electricity + service price
      s_detour  — based on distance from current to recommended zone
      s_charger — based on fast charger availability matching urgency

    Normalisation: each component independently min-max normalised
    over training distribution to ensure comparability.
    """

    def __init__(self, cfg: Config):
        self.cfg = cfg

    def score(
        self,
        occupancy:  float,   # predicted occupancy at chosen zone [0,1]
        cost:       float,   # normalised price [0,1]
        detour:     float,   # normalised distance [0,1]
        charger_ok: float,   # 1 if charger type matches urgency else 0
    ) -> float:
        """
        Higher score = more satisfied driver.
        Scores are weighted sum of individual satisfaction components.
        """
        s_wait    = 1.0 - occupancy      # low occupancy → low wait
        s_cost    = 1.0 - cost
        s_detour  = 1.0 - detour
        s_charger = charger_ok

        score = (
            self.cfg.reward_w_occupancy * s_wait
            + self.cfg.reward_w_cost    * s_cost
            + self.cfg.reward_w_distance * s_detour
            + self.cfg.reward_w_charger  * s_charger
        )
        return float(np.clip(score, 0.0, 1.0))


class EVChargingEnv(gym.Env):
    """
    Custom Gymnasium environment for urban EV charging zone recommendation.

    Objectives addressed:
      O1 — Agent recommends optimal zone from K neighbours
      O3 — Charger type allocation embedded in reward
      O4 — Congestion redistribution via occupancy-penalised reward

    State (69-dimensional):
      • Current zone: [occ, vol, dur, ep, sp, fast_ratio, pile_norm] × 1
      • K neighbours: [occ, vol, dur, ep, sp, fast_ratio, pile_norm] × K
      • Temporal:     [sin_h, cos_h, sin_d, cos_d, sin_m, cos_m] × 1

    Action:
      Discrete(K) — choose one of K neighbouring zones

    Reward:
      R = w_occ×(1-occ_chosen) + w_dist×(1-dist_norm) +
          w_cost×(1-price_norm) + w_chg×charger_match

    Episode:
      - Starts at random timestep t ∈ test range, random zone z
      - Step: agent recommends zone z' ∈ neighbours(z)
      - Next state: features at t+1 of z'
      - Episode ends after max_episode_steps steps
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        loader: object,
        forecasts_occ: np.ndarray,   # (N_test_samples, Z)
        forecasts_vol: np.ndarray,
        split:     str = "test",
        cfg:       Config = None,
    ):
        super().__init__()
        self.loader  = loader
        self.cfg     = cfg or Config()
        self.scorer  = SatisfactionScorer(self.cfg)
        K  = self.cfg.n_neighbors
        Fz = self.cfg.n_zone_features
        Ft = self.cfg.n_temporal_feats

        # Observation and action spaces
        obs_dim = (K + 1) * Fz + Ft
        self.observation_space = spaces.Box(
            low=-10.0, high=10.0, shape=(obs_dim,), dtype=np.float32
        )
        self.action_space = spaces.Discrete(K)

        # Build episode data arrays from split
        if split == "train":
            t_start, t_end = loader.cfg.window_size, loader.train_end
        elif split == "val":
            t_start, t_end = loader.train_end, loader.val_end
        else:
            T_total = (len(loader.timestamps)
                       if hasattr(loader,'timestamps') and loader.timestamps is not None
                       else loader.features.shape[0])
            t_start, t_end = loader.val_end, T_total

        self.t_start = t_start
        self.t_end   = t_end - loader.cfg.window_size
        self.features  = loader.features   # (T, Z, F)
        self.temporal  = loader.temporal   # (T, 6)
        self.dist_norm = loader.dist_norm  # (Z, Z)
        self.ep_raw    = loader.ep_raw     # (T, Z) electricity price
        self.sp_raw    = loader.sp_raw     # (T, Z) service price
        self.fast_ratio = loader.fast_ratio  # (Z,)
        self.neighbors  = loader.neighbors  # (Z, K)
        self.n_zones    = loader.n_zones

        # Pre-computed MTL occupancy forecasts (aligned to split window indices)
        self.occ_forecast = forecasts_occ  # (N, Z)
        self.forecast_idx  = 0             # index into forecast array

        # Episode state
        self.t:            int = t_start
        self.current_zone: int = 0
        self.steps:        int = 0
        self.episode_rewards: List[float] = []
        self.episode_satisfaction: List[float] = []

    def _get_obs(self, t: int, zone: int) -> np.ndarray:
        """Construct observation vector for (t, zone)."""
        nbrs = self.neighbors[zone][:self.cfg.n_neighbors]
        # Pad if zone has fewer than K neighbours
        while len(nbrs) < self.cfg.n_neighbors:
            nbrs = nbrs + [nbrs[-1]]

        feat_current  = self.features[t, zone]              # (F,)
        feat_nbrs     = np.stack([self.features[t, n] for n in nbrs])  # (K, F)
        feat_temporal = self.temporal[t]                    # (6,)

        obs = np.concatenate([
            feat_current.ravel(),
            feat_nbrs.ravel(),
            feat_temporal.ravel(),
        ], axis=0).astype(np.float32)
        return obs

    def reset(
        self,
        *,
        seed:    Optional[int] = None,
        options: Optional[dict] = None,
    ) -> Tuple[np.ndarray, dict]:
        super().reset(seed=seed)
        self.t            = self.np_random.integers(self.t_start, self.t_end)
        self.current_zone = self.np_random.integers(0, self.n_zones)
        self.steps        = 0
        self.forecast_idx = max(0, min(self.t - self.t_start,
                                       len(self.occ_forecast) - 1))
        self.episode_rewards.clear()
        self.episode_satisfaction.clear()
        return self._get_obs(self.t, self.current_zone), {}

    def step(
        self, action: int
    ) -> Tuple[np.ndarray, float, bool, bool, dict]:
        """
        Execute one recommendation step.

        Action: index into current zone's neighbour list → chosen zone.
        Reward: composite satisfaction score based on real outcomes.
        """
        nbrs         = self.neighbors[self.current_zone][:self.cfg.n_neighbors]
        chosen_zone  = nbrs[action] if action < len(nbrs) else nbrs[-1]

        # ── Occupancy: use MTL forecast (O2 → O4 coupling) ─────────────────
        f_idx       = min(self.forecast_idx, len(self.occ_forecast) - 1)
        occ_chosen  = float(np.clip(self.occ_forecast[f_idx, chosen_zone], 0, 1))

        # ── Distance cost ──────────────────────────────────────────────────
        dist_val    = float(self.dist_norm[self.current_zone, chosen_zone])

        # ── Price cost ─────────────────────────────────────────────────────
        ep  = float(self.ep_raw[self.t, chosen_zone])
        sp  = float(self.sp_raw[self.t, chosen_zone])
        # Normalise against episode max
        price_raw = ep + sp
        price_norm = float(np.clip(price_raw / (price_raw + 1e-4), 0, 1))

        # ── Charger match (O3) ─────────────────────────────────────────────
        # Urgency proxy: high current zone occupancy → driver needs fast charging
        cur_occ     = float(self.features[self.t, self.current_zone, 0])
        need_fast   = float(cur_occ > 0.7)   # normalised occ > 0.7 → urgent
        fast_avail  = float(self.fast_ratio[chosen_zone] > 0.2)
        charger_ok  = float(need_fast == fast_avail or (1 - need_fast))

        # ── Composite reward ───────────────────────────────────────────────
        satisfaction = self.scorer.score(occ_chosen, price_norm, dist_val, charger_ok)
        reward       = 2 * satisfaction - 1.0   # map [0,1] → [-1,1] for RL stability

        self.episode_rewards.append(reward)
        self.episode_satisfaction.append(satisfaction)

        # ── Transition ────────────────────────────────────────────────────
        self.current_zone  = chosen_zone
        self.t             = min(self.t + 1, self.t_end - 1)
        self.forecast_idx  = min(self.forecast_idx + 1, len(self.occ_forecast) - 1)
        self.steps        += 1

        done     = self.steps >= self.cfg.max_episode_steps
        obs      = self._get_obs(self.t, self.current_zone)

        # Estimate wait time: occupancy × mean_duration (O4 metric)
        mean_dur  = float(self.features[self.t, chosen_zone, 2])  # normalised dur
        est_wait  = occ_chosen * abs(mean_dur) * 60.0              # minutes proxy

        # O3: classify charger decision
        charger_type   = "fast" if (self.fast_ratio[chosen_zone] > 0.2) else "slow"
        fast_needed    = bool(cur_occ > 0.7)
        fast_chosen    = bool(self.fast_ratio[chosen_zone] > 0.2)
        correct_choice = bool(fast_needed == fast_chosen or not fast_needed)

        # O4: max occupancy among all available neighbours (congestion avoided)
        nbr_occs    = [float(np.clip(self.occ_forecast[f_idx, n], 0, 1))
                       for n in self.neighbors[self.current_zone][:self.cfg.n_neighbors]]
        max_nbr_occ = float(max(nbr_occs)) if nbr_occs else occ_chosen
        occ_avoided = max(0.0, max_nbr_occ - occ_chosen)  # how much congestion avoided

        info = {
            # O1 — routing
            "chosen_zone":      int(chosen_zone),
            "prev_zone":        int(self.current_zone),
            "distance":         float(dist_val),
            "distance_km":      float(dist_val * 30.0),      # approx km (dist_norm × 30km max)
            # O2 — forecast quality proxy
            "occupancy":        float(occ_chosen),
            "est_wait_min":     float(est_wait),
            # O3 — charger allocation
            "charger_type":     charger_type,
            "fast_needed":      fast_needed,
            "fast_chosen":      fast_chosen,
            "correct_charger":  correct_choice,
            "charger_ok":       float(charger_ok),
            # O4 — congestion
            "price_norm":       float(price_norm),
            "max_neighbour_occ": float(max_nbr_occ),
            "occ_avoided":      float(occ_avoided),
            "high_congestion":  bool(occ_chosen > 0.8),
            # O6 — satisfaction
            "satisfaction":     float(satisfaction),
        }
        return obs, float(reward), done, False, info

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 7: RL TRAINING (PPO)
# ══════════════════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 7: RL TRAINING
# ══════════════════════════════════════════════════════════════════════════════

class RLMetricsCallback(BaseCallback):
    """
    Custom SB3 callback: logs satisfaction score alongside standard RL metrics.
    Triggers best-model save based on mean satisfaction (not just reward).

    Note: SB3's BaseCallback already defines a `logger` property (read-only).
    We use `self._log` for our Python logger to avoid the name conflict.
    """

    def __init__(self, eval_env: "EVChargingEnv", cfg: Config, verbose: int = 0):
        super().__init__(verbose)
        self.eval_env  = eval_env
        self.cfg       = cfg
        self.best_sat  = -np.inf
        self.history   = defaultdict(list)
        self.save_path = Path(cfg.save_dir) / "rl" / "best_ppo_policy"
        self.save_path.parent.mkdir(parents=True, exist_ok=True)
        # Use _log (not logger) — BaseCallback.logger is a reserved property in SB3
        self._log = get_logger("RLCallback")

    def _on_step(self) -> bool:
        return True

    def _on_rollout_end(self) -> None:
        """Evaluate policy and log metrics after each rollout."""
        ep_rewards, ep_sat, ep_occ, ep_dist = [], [], [], []

        for _ in range(self.cfg.rl_n_eval_eps):
            obs, _ = self.eval_env.reset()
            done   = False
            ep_r   = 0.0
            while not done:
                action, _ = self.model.predict(obs, deterministic=True)
                obs, r, done, _, info = self.eval_env.step(int(action))
                ep_r  += r
                ep_sat.append(info["satisfaction"])
                ep_occ.append(info["occupancy"])
                ep_dist.append(info["distance"])

            ep_rewards.append(ep_r)

        mean_reward = np.mean(ep_rewards)
        mean_sat    = np.mean(ep_sat)
        mean_occ    = np.mean(ep_occ)
        mean_dist   = np.mean(ep_dist)

        self.history["mean_reward"].append(mean_reward)
        self.history["mean_satisfaction"].append(mean_sat)
        self.history["mean_occupancy"].append(mean_occ)
        self.history["mean_distance"].append(mean_dist)
        self.history["timestep"].append(self.num_timesteps)

        self._log.info(
            f"[Step {self.num_timesteps:7d}] "
            f"reward={mean_reward:.3f} | sat={mean_sat:.3f} | "
            f"occ={mean_occ:.3f} | dist={mean_dist:.3f}"
        )

        if mean_sat > self.best_sat:
            self.best_sat = mean_sat
            self.model.save(str(self.save_path))
            self._log.info(f"  ↑ New best satisfaction: {mean_sat:.4f}")


class RLTrainer:
    """
    Trains PPO agent on the EVChargingEnv.

    PPO rationale:
      - Stable training on non-stationary reward landscapes
      - Clip ratio prevents destructive policy updates
      - Entropy coefficient encourages exploration of 275-zone space
    """

    def __init__(self, env: "EVChargingEnv", eval_env: "EVChargingEnv", cfg: Config):
        self.cfg  = cfg
        self.logger = get_logger("RLTrainer")
        self.save_dir = Path(cfg.save_dir) / "rl"
        self.save_dir.mkdir(parents=True, exist_ok=True)

        # Wrap envs
        self.train_env = DummyVecEnv([lambda: Monitor(env)])
        self.eval_env  = eval_env

        self.callback = RLMetricsCallback(eval_env, cfg)

        self.model = PPO(
            "MlpPolicy",
            self.train_env,
            n_steps         = cfg.ppo_n_steps,
            batch_size      = cfg.ppo_batch_size,
            n_epochs        = cfg.ppo_n_epochs,
            gamma           = cfg.ppo_gamma,
            gae_lambda      = cfg.ppo_gae_lambda,
            clip_range      = cfg.ppo_clip_range,
            learning_rate   = cfg.ppo_learning_rate,
            ent_coef        = cfg.ppo_ent_coef,
            policy_kwargs   = {"net_arch": [256, 256, 128]},
            verbose         = 0,
            seed            = cfg.seed,
            tensorboard_log = None,  # disabled — tensorboard not required
        )

    def train(self) -> None:
        self.logger.info(
            f"Training PPO | steps={self.cfg.rl_total_steps} | "
            f"device={self.cfg.device}"
        )
        self.model.learn(
            total_timesteps       = self.cfg.rl_total_steps,
            callback              = self.callback,
            progress_bar          = False,
        )

        # Reload best policy
        best_path = str(self.save_dir / "best_ppo_policy")
        self.model = PPO.load(best_path, env=self.train_env)
        self.logger.info("Best PPO policy reloaded.")

    def evaluate(self, n_episodes: int = 100) -> Dict[str, float]:
        """
        Comprehensive RL evaluation metrics across all research objectives.

        O1 — Routing quality:
          mean_distance_km      — average detour distance (km proxy)
          zone_diversity        — unique zones visited / total steps (higher = better exploration)
          route_efficiency      — 1 - mean normalised distance (higher = shorter detours)

        O3 — Charger allocation:
          fast_charger_rate     — fraction of steps where fast charger was recommended
          correct_charger_rate  — fraction of steps where charger type matched urgency
          fast_when_needed_rate — fast chosen when urgency was high (true positive)
          slow_when_ok_rate     — slow chosen when urgency was low (true negative)

        O4 — Congestion redistribution:
          mean_occ_avoided      — average occupancy gap (max_neighbour - chosen)
          pct_high_congestion   — fraction of chosen zones with occ > 0.8 (lower = better)
          mean_est_wait_min     — estimated average wait time in minutes

        O6 — Satisfaction:
          mean_satisfaction     — overall composite score
          std_satisfaction      — consistency of recommendations
        """
        sat_scores, rewards, occs, dists = [], [], [], []
        # O1 tracking
        dist_kms, all_zones, route_seqs = [], [], []
        # O3 tracking
        fast_chosen_all, correct_charger_all = [], []
        fast_needed_all, fast_chosen_needed = [], []
        slow_ok_all = []
        # O4 tracking
        occ_avoided_all, high_cong_all, wait_min_all = [], [], []

        for ep in range(n_episodes):
            obs, _ = self.eval_env.reset()
            done   = False
            ep_r, ep_zones = 0.0, []

            while not done:
                action, _ = self.model.predict(obs, deterministic=True)
                obs, r, done, _, info = self.eval_env.step(int(action))
                ep_r += r
                # O1
                sat_scores.append(info["satisfaction"])
                occs.append(info["occupancy"])
                dists.append(info["distance"])
                dist_kms.append(info.get("distance_km", info["distance"] * 30))
                ep_zones.append(info["chosen_zone"])
                # O3
                fast_chosen_all.append(int(info.get("fast_chosen", False)))
                correct_charger_all.append(int(info.get("correct_charger", True)))
                if info.get("fast_needed", False):
                    fast_needed_all.append(int(info.get("fast_chosen", False)))
                if not info.get("fast_needed", False):
                    slow_ok_all.append(int(not info.get("fast_chosen", True)))
                # O4
                occ_avoided_all.append(info.get("occ_avoided", 0.0))
                high_cong_all.append(int(info.get("high_congestion", False)))
                wait_min_all.append(info.get("est_wait_min", 0.0))

            rewards.append(ep_r)
            all_zones.extend(ep_zones)
            route_seqs.append(ep_zones)

        greedy_sat, random_sat = self._baselines(n_episodes)

        # Zone diversity: unique zones visited as fraction of total steps
        zone_diversity = len(set(all_zones)) / max(len(all_zones), 1)

        metrics = {
            # ── Standard RL ───────────────────────────────────────────────
            "mean_episode_reward":    round(float(np.mean(rewards)),        4),
            "std_episode_reward":     round(float(np.std(rewards)),         4),
            # ── O1: Routing ───────────────────────────────────────────────
            "O1_mean_distance_norm":  round(float(np.mean(dists)),          4),
            "O1_mean_distance_km":    round(float(np.mean(dist_kms)),       4),
            "O1_route_efficiency":    round(1.0 - float(np.mean(dists)),    4),
            "O1_zone_diversity":      round(float(zone_diversity),          4),
            "O1_unique_zones_visited":int(len(set(all_zones))),
            # ── O3: Charger Allocation ────────────────────────────────────
            "O3_fast_charger_rate":   round(float(np.mean(fast_chosen_all)),4),
            "O3_correct_charger_rate":round(float(np.mean(correct_charger_all)),4),
            "O3_fast_when_needed":    round(float(np.mean(fast_needed_all)) if fast_needed_all else 0.0, 4),
            "O3_slow_when_ok":        round(float(np.mean(slow_ok_all)) if slow_ok_all else 0.0, 4),
            # ── O4: Congestion ────────────────────────────────────────────
            "O4_mean_occ_avoided":    round(float(np.mean(occ_avoided_all)),4),
            "O4_pct_high_congestion": round(float(np.mean(high_cong_all)),  4),
            "O4_mean_wait_min":       round(float(np.mean(wait_min_all)),   4),
            "O4_mean_occupancy":      round(float(np.mean(occs)),           4),
            # ── O6: Satisfaction ──────────────────────────────────────────
            "O6_mean_satisfaction":   round(float(np.mean(sat_scores)),     4),
            "O6_std_satisfaction":    round(float(np.std(sat_scores)),      4),
            "O6_greedy_satisfaction": round(float(greedy_sat),              4),
            "O6_random_satisfaction": round(float(random_sat),              4),
            "O6_gain_vs_greedy":      round(float(np.mean(sat_scores)) - float(greedy_sat), 4),
            "O6_gain_vs_random":      round(float(np.mean(sat_scores)) - float(random_sat), 4),
        }

        # Store route sequences for visualisation
        self._route_seqs   = route_seqs
        self._sat_scores   = sat_scores
        self._fast_choices = list(zip(fast_needed_all, [bool(x) for x in fast_chosen_all[:len(fast_needed_all)]]))

        return metrics

    def _baselines(self, n_episodes: int) -> Tuple[float, float]:
        """Evaluate greedy and random baselines for comparison."""
        greedy_sats, random_sats = [], []

        for _ in range(n_episodes):
            # Greedy baseline
            obs, _ = self.eval_env.reset()
            done   = False
            while not done:
                _, r, done, _, info = self.eval_env.step(0)  # always choose nearest
                greedy_sats.append(info["satisfaction"])

            # Random baseline
            obs, _ = self.eval_env.reset()
            done   = False
            while not done:
                action = self.eval_env.action_space.sample()
                _, r, done, _, info = self.eval_env.step(action)
                random_sats.append(info["satisfaction"])

        return float(np.mean(greedy_sats)), float(np.mean(random_sats))

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 8: LLM EXPLANATION MODULE
# ══════════════════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════════════
# SECTION 8: LLM EXPLANATION MODULE (O6)
# ══════════════════════════════════════════════════════════════════════════════

class LLMExplainer:
    """
    LLM-based satisfaction verdict generator for EV charging zone recommendations (O6).

    Design goal:
      Given the RL agent's decision (zone, occupancy, distance, price, charger type)
      and the resulting satisfaction score, generate a clear human-readable CAPTION
      that states:
        1. Whether the customer is SATISFIED, PARTIALLY SATISFIED, or UNSATISFIED
        2. The specific reasons from the data that drove that verdict
        3. What factor hurt or helped satisfaction most

    Architecture:
      - INPUT  : Structured decision context (all numeric values + derived labels)
      - SCORING: Rule-based verdict engine maps numeric signals → satisfaction factors
      - LLM    : GPT-2 generates the natural-language caption from a tight prefix
                 ("The driver is satisfied because..." / "The driver is unsatisfied because...")
                 GPT-2 only fills in the natural language — the verdict itself is
                 deterministic from the score, preventing hallucination.
      - FALLBACK: If GPT-2 is unavailable, a deterministic template produces an
                 equivalent structured caption.

    This design is more reliable than unconstrained generation because:
      - The SATISFIED/UNSATISFIED verdict is always correct (rule-based from score)
      - The reasons are pre-identified from data before GPT-2 generates text
      - GPT-2 only adds fluency, not content — so it cannot contradict the data
    """

    # Thresholds for verdict classification
    SAT_HIGH   = 0.70   # score >= SAT_HIGH  → SATISFIED
    SAT_LOW    = 0.45   # score <  SAT_LOW   → UNSATISFIED
                        # else               → PARTIALLY SATISFIED

    def __init__(self, cfg: Config):
        self.cfg     = cfg
        self.logger  = get_logger("LLMExplainer")
        self.use_llm = globals().get("HF_AVAILABLE", True)

        if self.use_llm:
            self.logger.info(f"Loading {cfg.llm_model_name} for caption generation ...")
            try:
                self.tokeniser = GPT2Tokenizer.from_pretrained(cfg.llm_model_name)
                self.model     = GPT2LMHeadModel.from_pretrained(cfg.llm_model_name)
                self.tokeniser.pad_token = self.tokeniser.eos_token
                self.model.eval()
                self.device = "cpu"
                self.model.to(self.device)
                self.logger.info("GPT-2 loaded — will generate natural-language captions.")
            except Exception as e:
                self.logger.warning(f"GPT-2 load failed ({e}). Using template captions.")
                self.use_llm = False
        else:
            self.logger.warning("HF not available — using deterministic template captions.")

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 1: Extract structured factors from raw info dict
    # ─────────────────────────────────────────────────────────────────────────

    def _extract_factors(self, info: Dict) -> Dict:
        """
        Convert raw numeric info dict into labelled satisfaction factors.
        Each factor carries: value, label, sentiment (+/-), and explanation text.
        This is the shared analysis used by both the LLM prompt and the fallback.
        """
        occ   = float(info.get("occupancy",    0.5))
        dist  = float(info.get("distance",     0.5))
        price = float(info.get("price_norm",   0.5))
        sat   = float(info.get("satisfaction", 0.5))
        zone  = info.get("chosen_zone", "N/A")
        prev  = info.get("prev_zone",   "N/A")
        wait  = float(info.get("est_wait_min", 0.0))
        chg_t = info.get("charger_type", "slow")
        f_nee = bool(info.get("fast_needed",  False))
        f_cho = bool(info.get("fast_chosen",  False))
        o_av  = float(info.get("occ_avoided",  0.0))
        dk    = float(info.get("distance_km",  dist * 30))

        # ── Verdict ─────────────────────────────────────────────────────────
        if sat >= self.SAT_HIGH:
            verdict = "SATISFIED"
            verdict_emoji = "✅"
        elif sat >= self.SAT_LOW:
            verdict = "PARTIALLY SATISFIED"
            verdict_emoji = "⚠️"
        else:
            verdict = "UNSATISFIED"
            verdict_emoji = "❌"

        # ── Individual factor sentiments ─────────────────────────────────────
        factors = []

        # Availability / Wait time
        if occ < 0.35:
            factors.append({
                "name": "Availability",
                "sentiment": "+",
                "detail": f"Zone {zone} has low occupancy ({occ:.0%}) — charging slot available immediately",
                "wait_note": f"estimated wait: {wait:.0f} min",
            })
        elif occ < 0.70:
            factors.append({
                "name": "Availability",
                "sentiment": "~",
                "detail": f"Zone {zone} is moderately busy ({occ:.0%}) — short wait expected",
                "wait_note": f"estimated wait: {wait:.0f} min",
            })
        else:
            factors.append({
                "name": "Availability",
                "sentiment": "-",
                "detail": f"Zone {zone} is congested ({occ:.0%}) — significant wait likely",
                "wait_note": f"estimated wait: {wait:.0f} min",
            })

        # Distance / Detour
        if dk < 1.5:
            factors.append({
                "name": "Distance",
                "sentiment": "+",
                "detail": f"Zone is very close ({dk:.1f} km) — minimal detour from current location",
            })
        elif dk < 4.0:
            factors.append({
                "name": "Distance",
                "sentiment": "~",
                "detail": f"Zone is at moderate distance ({dk:.1f} km) — acceptable detour",
            })
        else:
            factors.append({
                "name": "Distance",
                "sentiment": "-",
                "detail": f"Zone is far ({dk:.1f} km) — notable travel overhead required",
            })

        # Price
        if price < 0.35:
            factors.append({
                "name": "Price",
                "sentiment": "+",
                "detail": f"Charging cost is low (price index: {price:.2f}) — economical choice",
            })
        elif price < 0.65:
            factors.append({
                "name": "Price",
                "sentiment": "~",
                "detail": f"Charging cost is moderate (price index: {price:.2f})",
            })
        else:
            factors.append({
                "name": "Price",
                "sentiment": "-",
                "detail": f"Charging cost is high (price index: {price:.2f}) — may deter driver",
            })

        # Charger type match
        if f_nee and f_cho:
            factors.append({
                "name": "Charger",
                "sentiment": "+",
                "detail": f"Fast DC charger available — matches driver urgency",
            })
        elif not f_nee and not f_cho:
            factors.append({
                "name": "Charger",
                "sentiment": "+",
                "detail": f"Standard AC charger appropriate — battery level is comfortable",
            })
        elif f_nee and not f_cho:
            factors.append({
                "name": "Charger",
                "sentiment": "-",
                "detail": f"Driver needs fast charging but only standard AC available — urgency unmet",
            })
        else:
            factors.append({
                "name": "Charger",
                "sentiment": "~",
                "detail": f"Fast charger available but not urgently needed — adequate",
            })

        # Congestion relief
        if o_av > 0.10:
            factors.append({
                "name": "Congestion",
                "sentiment": "+",
                "detail": f"RL agent redirected driver to a less congested zone "
                          f"(avoided {o_av:.0%} higher occupancy elsewhere)",
            })
        elif o_av > 0.0:
            factors.append({
                "name": "Congestion",
                "sentiment": "~",
                "detail": f"Minor congestion avoidance benefit ({o_av:.0%})",
            })

        # ── Identify dominant factor ──────────────────────────────────────────
        pos_factors = [f["name"] for f in factors if f["sentiment"] == "+"]
        neg_factors = [f["name"] for f in factors if f["sentiment"] == "-"]
        neutral_factors = [f["name"] for f in factors if f["sentiment"] == "~"]

        return {
            "zone":          zone,
            "prev_zone":     prev,
            "sat":           sat,
            "verdict":       verdict,
            "verdict_emoji": verdict_emoji,
            "factors":       factors,
            "pos_factors":   pos_factors,
            "neg_factors":   neg_factors,
            "neutral_factors": neutral_factors,
            "occ": occ, "dk": dk, "price": price,
            "wait": wait, "chg_t": chg_t,
        }

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 2: Build the LLM prompt — tight prefix approach
    # ─────────────────────────────────────────────────────────────────────────

    def _build_prompt(self, factors: Dict) -> str:
        """
        Build a tight GPT-2 completion prefix.

        Design principle: Tell GPT-2 the verdict and main reason FIRST,
        then ask it to complete the sentence. This way:
          - The verdict is always correct (we wrote it)
          - GPT-2 only adds fluency and detail
          - Output stays on-topic and does not hallucinate a different verdict

        The INPUT section shown to the user is the full structured data.
        The LLM only sees the short completion prefix.
        """
        v      = factors["verdict"]
        pos    = factors["pos_factors"]
        neg    = factors["neg_factors"]
        zone   = factors["zone"]
        occ    = factors["occ"]
        dk     = factors["dk"]
        price  = factors["price"]
        wait   = factors["wait"]

        # Compose the prefix that GPT-2 will complete
        if v == "SATISFIED":
            main_reason = pos[0].lower() if pos else "low occupancy"
            prefix = (
                f"The EV driver is satisfied with Zone {zone} because "
                f"the {main_reason} conditions are favourable. "
                f"The zone has {occ:.0%} occupancy with an estimated wait of "
                f"{wait:.0f} minutes and a travel distance of {dk:.1f} km. "
                f"Overall, this recommendation meets driver expectations because"
            )
        elif v == "UNSATISFIED":
            main_issue = neg[0].lower() if neg else "high occupancy"
            prefix = (
                f"The EV driver is unsatisfied with Zone {zone} due to "
                f"unfavourable {main_issue} conditions. "
                f"The zone has {occ:.0%} occupancy requiring approximately "
                f"{wait:.0f} minutes of waiting and is {dk:.1f} km away. "
                f"This recommendation falls short of driver expectations because"
            )
        else:  # PARTIALLY SATISFIED
            prefix = (
                f"The EV driver has mixed satisfaction with Zone {zone}. "
                f"While some conditions are acceptable (occupancy: {occ:.0%}, "
                f"distance: {dk:.1f} km), others are suboptimal (price index: {price:.2f}). "
                f"The estimated wait time is {wait:.0f} minutes. "
                f"This recommendation partially meets driver needs because"
            )
        return prefix

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 3: Generate completion with GPT-2
    # ─────────────────────────────────────────────────────────────────────────

    def _generate_completion(self, prefix: str) -> str:
        """
        GPT-2 completes the natural-language sentence.
        Only generates the continuation after the tight prefix.
        """
        inputs = self.tokeniser(
            prefix,
            return_tensors    = "pt",
            truncation        = True,
            max_length        = 200,
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens        = self.cfg.llm_max_new_tokens,
                temperature           = self.cfg.llm_temperature,
                top_p                 = self.cfg.llm_top_p,
                do_sample             = True,
                pad_token_id          = self.tokeniser.eos_token_id,
                repetition_penalty    = 1.3,
                no_repeat_ngram_size  = 3,
            )

        full = self.tokeniser.decode(outputs[0], skip_special_tokens=True)
        completion = full[len(prefix):].strip()

        # Clean up: take only first complete sentence
        for end_char in ['.', '!', '?']:
            idx = completion.find(end_char)
            if 0 < idx < 200:
                completion = completion[:idx+1]
                break

        return completion if completion else "the overall conditions are adequate."

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 4: Template fallback (no GPT-2 needed)
    # ─────────────────────────────────────────────────────────────────────────

    def _template_completion(self, factors: Dict) -> str:
        """
        Deterministic template caption when GPT-2 is unavailable.
        Produces the same structured output as GPT-2 completion.
        """
        pos  = factors["pos_factors"]
        neg  = factors["neg_factors"]
        v    = factors["verdict"]
        wait = factors["wait"]
        dk   = factors["dk"]
        occ  = factors["occ"]

        if v == "SATISFIED":
            if len(pos) >= 2:
                return (f"it offers {pos[0].lower()} and {pos[1].lower()} advantages, "
                        f"with {occ:.0%} zone occupancy and {wait:.0f} min estimated wait.")
            return (f"it provides {pos[0].lower() if pos else 'adequate'} conditions "
                    f"with {wait:.0f} min estimated wait at {dk:.1f} km distance.")
        elif v == "UNSATISFIED":
            if len(neg) >= 2:
                return (f"both {neg[0].lower()} and {neg[1].lower()} conditions are poor, "
                        f"with {occ:.0%} occupancy causing an estimated {wait:.0f} min wait.")
            return (f"the {neg[0].lower() if neg else 'overall'} conditions do not meet "
                    f"driver requirements, with {wait:.0f} min estimated wait.")
        else:
            pos_str = f"{pos[0].lower()} is favourable" if pos else "some factors are acceptable"
            neg_str = f"{neg[0].lower()} is suboptimal" if neg else "some factors need improvement"
            return f"{pos_str} but {neg_str}, resulting in moderate driver satisfaction."

    # ─────────────────────────────────────────────────────────────────────────
    # PUBLIC API
    # ─────────────────────────────────────────────────────────────────────────

    def explain(self, info: Dict) -> Tuple[str, str]:
        """
        Generate a satisfaction verdict caption for one RL decision.

        Returns:
          (input_summary, output_caption)

          input_summary  — structured display of all decision inputs
                           (what the model saw + the RL satisfaction score)
          output_caption — verdict + reasons caption
                           Format: "[VERDICT]: [Primary reason]. [Supporting reasons]."

        Example output:
          ✅ SATISFIED: Zone 142 was recommended because the availability
          conditions are excellent (15% occupancy, 2 min wait). The nearby
          distance of 1.2 km and affordable pricing further contribute to
          high driver satisfaction (score: 0.81).
        """
        fac = self._extract_factors(info)

        # ── Build human-readable INPUT summary ───────────────────────────────
        factor_lines = "\n".join(
            f"    [{f['sentiment']}] {f['name']:12s}: {f['detail']}"
            for f in fac["factors"]
        )
        sat = fac["sat"]
        input_summary = (
            "┌─ DECISION INPUT ────────────────────────────────────────────┐\n"
            f"│  From Zone {fac['prev_zone']} → Recommended Zone {fac['zone']}\n"
            f"│  RL Satisfaction Score : {sat:.4f} / 1.0\n"
            "│  Score breakdown:\n"
            f"{factor_lines}\n"
            "└─────────────────────────────────────────────────────────────┘"
        )

        # ── Generate OUTPUT caption ───────────────────────────────────────────
        prefix     = self._build_prompt(fac)
        if getattr(self, "use_llm", False):
            completion = self._generate_completion(prefix)
        else:
            completion = self._template_completion(fac)

        # Assemble final caption
        pos_str = (", ".join(fac["pos_factors"]) + " conditions are favourable"
                   if fac["pos_factors"] else "")
        neg_str = (", ".join(fac["neg_factors"]) + " conditions are suboptimal"
                   if fac["neg_factors"] else "")
        context = " | ".join(filter(None, [pos_str, neg_str])) or "mixed conditions"

        output_caption = (
            f"{fac['verdict_emoji']} {fac['verdict']}\n"
            f"Zone {fac['zone']} — {context}.\n"
            f"{prefix} {completion.lstrip()}\n"
            f"[Satisfaction score: {sat:.4f}]"
        )

        return input_summary, output_caption

    def compute_perplexity(self, text: str) -> float:
        """
        Compute GPT-2 perplexity of the generated caption completion.
        Lower perplexity = more fluent, natural text.
        Returns 50.0 baseline when GPT-2 is unavailable.
        """
        if not getattr(self, "use_llm", False):
            return 50.0
        if not text or len(text) < 5:
            return 999.0
        try:
            enc = self.tokeniser(
                text, return_tensors="pt", truncation=True, max_length=128
            ).to(self.device)
            if enc.input_ids.shape[1] < 2:
                return 999.0
            with torch.no_grad():
                loss = self.model(**enc, labels=enc.input_ids).loss
            return float(torch.exp(loss))
        except Exception:
            return 50.0

    def batch_explain_and_evaluate(
        self,
        episode_infos: List[Dict],
        n_samples:     int = 30,
    ) -> Dict[str, float]:
        """
        Generate captions for a batch of episodes and compute quality metrics.

        Metrics:
          LLM_satisfied_rate    — fraction of episodes classified SATISFIED
          LLM_unsatisfied_rate  — fraction classified UNSATISFIED
          LLM_partial_rate      — fraction classified PARTIALLY SATISFIED
          LLM_verdict_sat_corr  — Pearson r between numeric score and verdict
                                  (1.0 = perfect alignment between score and verdict)
          LLM_mean_perplexity   — GPT-2 fluency of generated captions
          LLM_mean_expl_length  — average caption length in characters
        """
        samples = random.sample(episode_infos, min(n_samples, len(episode_infos)))
        verdicts, sat_scores, perplexities, lengths = [], [], [], []

        verdict_map = {"SATISFIED": 1.0, "PARTIALLY SATISFIED": 0.5, "UNSATISFIED": 0.0}

        for info in samples:
            inp, cap = self.explain(info)
            fac = self._extract_factors(info)
            verdicts.append(verdict_map.get(fac["verdict"], 0.5))
            sat_scores.append(float(info.get("satisfaction", 0.5)))
            perplexities.append(self.compute_perplexity(cap))
            lengths.append(len(cap))

        # Verdict-score alignment: should be high (positive correlation)
        try:
            corr, _ = pearsonr(sat_scores, verdicts)
            corr = float(corr) if not np.isnan(corr) else 0.0
        except Exception:
            corr = 0.0

        n = max(len(verdicts), 1)
        return {
            "LLM_satisfied_rate":   round(sum(v == 1.0 for v in verdicts) / n, 4),
            "LLM_partial_rate":     round(sum(v == 0.5 for v in verdicts) / n, 4),
            "LLM_unsatisfied_rate": round(sum(v == 0.0 for v in verdicts) / n, 4),
            "LLM_verdict_sat_corr": round(corr,                               4),
            "LLM_mean_perplexity":  round(float(np.mean(perplexities)),       2),
            "LLM_mean_expl_length": round(float(np.mean(lengths)),            1),
        }